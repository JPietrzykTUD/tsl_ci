/*==========================================================================*
 * This file is part of the TSL - a template SIMD library.                  *
 *                                                                          *
 * Copyright 2024 TSL-Team, Database Research Group TU Dresden              *
 *                                                                          *
 * Licensed under the Apache License, Version 2.0 (the "License");          *
 * you may not use this file except in compliance with the License.         *
 * You may obtain a copy of the License at                                  *
 *                                                                          *
 *     http://www.apache.org/licenses/LICENSE-2.0                           *
 *                                                                          *
 * Unless required by applicable law or agreed to in writing, software      *
 * distributed under the License is distributed on an "AS IS" BASIS,        *
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. *
 * See the License for the specific language governing permissions and      *
 * limitations under the License.                                           *
 *==========================================================================*/
/*
 * \file /github/workspace/ci/generation/sse_sse2_ssse3_sse4_1_sse4_2_avx_avx2_avx512f/include/generated/definitions/calc/calc_avx512.hpp
 * \date 2024-03-05
 * \brief This file contains arithmetic primitives.
 * \note
 * Git-Local Url : /github/workspace
 * Git-Remote Url: unknown url
 * Git-Branch    : unknown branch
 * Git-Commit    : unknown commit (unknown commit)
 *
 */
#ifndef TUD_D2RG_TSL_GITHUB_WORKSPACE_CI_GENERATION_SSE_SSE2_SSSE3_SSE4_1_SSE4_2_AVX_AVX2_AVX512F_INCLUDE_GENERATED_DEFINITIONS_CALC_CALC_AVX512_HPP
#define TUD_D2RG_TSL_GITHUB_WORKSPACE_CI_GENERATION_SSE_SSE2_SSSE3_SSE4_1_SSE4_2_AVX_AVX2_AVX512F_INCLUDE_GENERATED_DEFINITIONS_CALC_CALC_AVX512_HPP

#include <array>
#include <cstddef>
#include <cmath>
#include <algorithm>
#include "../../declarations/calc.hpp"
#include <tuple>

namespace tsl {

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "add" (primitive add).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::81
         * @note: Signed addition.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct add<simd<uint32_t, avx512>, Idof> {
            using Vec = simd<uint32_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_add_epi32(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of add for avx512 using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "add" (primitive add).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::81
         * @note: Signed addition.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct add<simd<uint64_t, avx512>, Idof> {
            using Vec = simd<uint64_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_add_epi64(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of add for avx512 using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "add" (primitive add).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::81
         * @note: Signed addition.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct add<simd<int32_t, avx512>, Idof> {
            using Vec = simd<int32_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_add_epi32(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of add for avx512 using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "add" (primitive add).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::81
         * @note: Signed addition.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct add<simd<int64_t, avx512>, Idof> {
            using Vec = simd<int64_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_add_epi64(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of add for avx512 using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "add" (primitive add).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::91
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct add<simd<float, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_add_ps(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of add for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "add" (primitive add).
         * @details:
         * Target Extension: avx512.
         *        Data Type: double
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::91
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct add<simd<double, avx512>, Idof> {
            using Vec = simd<double, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_add_pd(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of add for avx512 using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "sub" (primitive sub).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::219
         * @note: Signed addition.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct sub<simd<uint32_t, avx512>, Idof> {
            using Vec = simd<uint32_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_sub_epi32(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of sub for avx512 using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "sub" (primitive sub).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::219
         * @note: Signed addition.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct sub<simd<uint64_t, avx512>, Idof> {
            using Vec = simd<uint64_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_sub_epi64(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of sub for avx512 using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "sub" (primitive sub).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::219
         * @note: Signed addition.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct sub<simd<int32_t, avx512>, Idof> {
            using Vec = simd<int32_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_sub_epi32(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of sub for avx512 using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "sub" (primitive sub).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::219
         * @note: Signed addition.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct sub<simd<int64_t, avx512>, Idof> {
            using Vec = simd<int64_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_sub_epi64(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of sub for avx512 using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "sub" (primitive sub).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::229
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct sub<simd<float, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_sub_ps(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of sub for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "sub" (primitive sub).
         * @details:
         * Target Extension: avx512.
         *        Data Type: double
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::229
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct sub<simd<double, avx512>, Idof> {
            using Vec = simd<double, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_sub_pd(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of sub for avx512 using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mask_add" (primitive add).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::358
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mask_add<simd<float, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::mask_type, const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::mask_type mask, const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_mask_add_ps(vec_a, mask, vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of mask_add for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mask_add" (primitive add).
         * @details:
         * Target Extension: avx512.
         *        Data Type: double
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::358
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mask_add<simd<double, avx512>, Idof> {
            using Vec = simd<double, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::mask_type, const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::mask_type mask, const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_mask_add_pd(vec_a, mask, vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of mask_add for avx512 using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mul" (primitive mul).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::508
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mul<simd<float, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_mul_ps(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of mul for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mul" (primitive mul).
         * @details:
         * Target Extension: avx512.
         *        Data Type: double
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::508
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mul<simd<double, avx512>, Idof> {
            using Vec = simd<double, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_mul_pd(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of mul for avx512 using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mul" (primitive mul).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::521
         * @note: Signed multiplication.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mul<simd<uint32_t, avx512>, Idof> {
            using Vec = simd<uint32_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_mullo_epi32(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of mul for avx512 using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mul" (primitive mul).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::521
         * @note: Signed multiplication.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mul<simd<int32_t, avx512>, Idof> {
            using Vec = simd<int32_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_mullo_epi32(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of mul for avx512 using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mul" (primitive mul).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::531
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mul<simd<uint8_t, avx512>, Idof> {
            using Vec = simd<uint8_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive mul is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_a;
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_b;
                _mm512_store_si512(reinterpret_cast<void*>(buffer_a.data()), vec_a);
                _mm512_store_si512(reinterpret_cast<void*>(buffer_b.data()), vec_b);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                    buffer_a[i] *= buffer_b[i];
                }
                return _mm512_load_si512(reinterpret_cast<void const *>(buffer_a.data()));
            }
        };
    } // end of namespace functors for template specialization of mul for avx512 using uint8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mul" (primitive mul).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::531
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mul<simd<int8_t, avx512>, Idof> {
            using Vec = simd<int8_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive mul is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_a;
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_b;
                _mm512_store_si512(reinterpret_cast<void*>(buffer_a.data()), vec_a);
                _mm512_store_si512(reinterpret_cast<void*>(buffer_b.data()), vec_b);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                    buffer_a[i] *= buffer_b[i];
                }
                return _mm512_load_si512(reinterpret_cast<void const *>(buffer_a.data()));
            }
        };
    } // end of namespace functors for template specialization of mul for avx512 using int8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mul" (primitive mul).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::531
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mul<simd<uint16_t, avx512>, Idof> {
            using Vec = simd<uint16_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive mul is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_a;
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_b;
                _mm512_store_si512(reinterpret_cast<void*>(buffer_a.data()), vec_a);
                _mm512_store_si512(reinterpret_cast<void*>(buffer_b.data()), vec_b);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                    buffer_a[i] *= buffer_b[i];
                }
                return _mm512_load_si512(reinterpret_cast<void const *>(buffer_a.data()));
            }
        };
    } // end of namespace functors for template specialization of mul for avx512 using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mul" (primitive mul).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::531
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mul<simd<int16_t, avx512>, Idof> {
            using Vec = simd<int16_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive mul is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_a;
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_b;
                _mm512_store_si512(reinterpret_cast<void*>(buffer_a.data()), vec_a);
                _mm512_store_si512(reinterpret_cast<void*>(buffer_b.data()), vec_b);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                    buffer_a[i] *= buffer_b[i];
                }
                return _mm512_load_si512(reinterpret_cast<void const *>(buffer_a.data()));
            }
        };
    } // end of namespace functors for template specialization of mul for avx512 using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mul" (primitive mul).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::531
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mul<simd<uint64_t, avx512>, Idof> {
            using Vec = simd<uint64_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive mul is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_a;
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_b;
                _mm512_store_si512(reinterpret_cast<void*>(buffer_a.data()), vec_a);
                _mm512_store_si512(reinterpret_cast<void*>(buffer_b.data()), vec_b);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                    buffer_a[i] *= buffer_b[i];
                }
                return _mm512_load_si512(reinterpret_cast<void const *>(buffer_a.data()));
            }
        };
    } // end of namespace functors for template specialization of mul for avx512 using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mul" (primitive mul).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::531
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mul<simd<int64_t, avx512>, Idof> {
            using Vec = simd<int64_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive mul is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_a;
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_b;
                _mm512_store_si512(reinterpret_cast<void*>(buffer_a.data()), vec_a);
                _mm512_store_si512(reinterpret_cast<void*>(buffer_b.data()), vec_b);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                    buffer_a[i] *= buffer_b[i];
                }
                return _mm512_load_si512(reinterpret_cast<void const *>(buffer_a.data()));
            }
        };
    } // end of namespace functors for template specialization of mul for avx512 using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mul_constant" (primitive mul).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::678
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mul_constant<simd<float, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::base_type mul_var
            ) {
                return _mm512_mul_ps(vec_a, tsl::set1<Vec>(mul_var));
            }
        };
    } // end of namespace functors for template specialization of mul_constant for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mul_constant" (primitive mul).
         * @details:
         * Target Extension: avx512.
         *        Data Type: double
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::678
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mul_constant<simd<double, avx512>, Idof> {
            using Vec = simd<double, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::base_type mul_var
            ) {
                return _mm512_mul_pd(vec_a, tsl::set1<Vec>(mul_var));
            }
        };
    } // end of namespace functors for template specialization of mul_constant for avx512 using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mul_constant" (primitive mul).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::691
         * @note: Signed multiplication.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mul_constant<simd<uint32_t, avx512>, Idof> {
            using Vec = simd<uint32_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::base_type mul_var
            ) {
                return _mm512_mullo_epi32(vec_a, tsl::set1<Vec>(mul_var));
            }
        };
    } // end of namespace functors for template specialization of mul_constant for avx512 using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mul_constant" (primitive mul).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::691
         * @note: Signed multiplication.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mul_constant<simd<int32_t, avx512>, Idof> {
            using Vec = simd<int32_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::base_type mul_var
            ) {
                return _mm512_mullo_epi32(vec_a, tsl::set1<Vec>(mul_var));
            }
        };
    } // end of namespace functors for template specialization of mul_constant for avx512 using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mul_constant" (primitive mul).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::701
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mul_constant<simd<uint8_t, avx512>, Idof> {
            using Vec = simd<uint8_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::base_type mul_var
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive mul_constant is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_a;
                _mm512_store_si512(reinterpret_cast<void*>(buffer_a.data()), vec_a);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                    buffer_a[i] *= mul_var;
                }
                return _mm512_load_si512(reinterpret_cast<void const *>(buffer_a.data()));
            }
        };
    } // end of namespace functors for template specialization of mul_constant for avx512 using uint8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mul_constant" (primitive mul).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::701
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mul_constant<simd<int8_t, avx512>, Idof> {
            using Vec = simd<int8_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::base_type mul_var
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive mul_constant is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_a;
                _mm512_store_si512(reinterpret_cast<void*>(buffer_a.data()), vec_a);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                    buffer_a[i] *= mul_var;
                }
                return _mm512_load_si512(reinterpret_cast<void const *>(buffer_a.data()));
            }
        };
    } // end of namespace functors for template specialization of mul_constant for avx512 using int8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mul_constant" (primitive mul).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::701
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mul_constant<simd<uint16_t, avx512>, Idof> {
            using Vec = simd<uint16_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::base_type mul_var
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive mul_constant is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_a;
                _mm512_store_si512(reinterpret_cast<void*>(buffer_a.data()), vec_a);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                    buffer_a[i] *= mul_var;
                }
                return _mm512_load_si512(reinterpret_cast<void const *>(buffer_a.data()));
            }
        };
    } // end of namespace functors for template specialization of mul_constant for avx512 using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mul_constant" (primitive mul).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::701
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mul_constant<simd<int16_t, avx512>, Idof> {
            using Vec = simd<int16_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::base_type mul_var
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive mul_constant is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_a;
                _mm512_store_si512(reinterpret_cast<void*>(buffer_a.data()), vec_a);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                    buffer_a[i] *= mul_var;
                }
                return _mm512_load_si512(reinterpret_cast<void const *>(buffer_a.data()));
            }
        };
    } // end of namespace functors for template specialization of mul_constant for avx512 using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mul_constant" (primitive mul).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::701
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mul_constant<simd<uint64_t, avx512>, Idof> {
            using Vec = simd<uint64_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::base_type mul_var
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive mul_constant is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_a;
                _mm512_store_si512(reinterpret_cast<void*>(buffer_a.data()), vec_a);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                    buffer_a[i] *= mul_var;
                }
                return _mm512_load_si512(reinterpret_cast<void const *>(buffer_a.data()));
            }
        };
    } // end of namespace functors for template specialization of mul_constant for avx512 using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mul_constant" (primitive mul).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::701
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mul_constant<simd<int64_t, avx512>, Idof> {
            using Vec = simd<int64_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::base_type mul_var
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive mul_constant is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_a;
                _mm512_store_si512(reinterpret_cast<void*>(buffer_a.data()), vec_a);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                    buffer_a[i] *= mul_var;
                }
                return _mm512_load_si512(reinterpret_cast<void const *>(buffer_a.data()));
            }
        };
    } // end of namespace functors for template specialization of mul_constant for avx512 using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hadd" (primitive hadd).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::876
         * @note: Be aware, that this intrinsic is flagged as 'sequence' by INTEL.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hadd<simd<float, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type value
            ) {
                return _mm512_reduce_add_ps(value);
            }
        };
    } // end of namespace functors for template specialization of hadd for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hadd" (primitive hadd).
         * @details:
         * Target Extension: avx512.
         *        Data Type: double
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::876
         * @note: Be aware, that this intrinsic is flagged as 'sequence' by INTEL.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hadd<simd<double, avx512>, Idof> {
            using Vec = simd<double, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type value
            ) {
                return _mm512_reduce_add_pd(value);
            }
        };
    } // end of namespace functors for template specialization of hadd for avx512 using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hadd" (primitive hadd).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::881
         * @note: Signed Addition. Be aware, that this intrinsic is flagged as 'sequence' by INTEL.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hadd<simd<uint32_t, avx512>, Idof> {
            using Vec = simd<uint32_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type value
            ) {
                return _mm512_reduce_add_epi32(value);
            }
        };
    } // end of namespace functors for template specialization of hadd for avx512 using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hadd" (primitive hadd).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::881
         * @note: Signed Addition. Be aware, that this intrinsic is flagged as 'sequence' by INTEL.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hadd<simd<uint64_t, avx512>, Idof> {
            using Vec = simd<uint64_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type value
            ) {
                return _mm512_reduce_add_epi64(value);
            }
        };
    } // end of namespace functors for template specialization of hadd for avx512 using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hadd" (primitive hadd).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::881
         * @note: Signed Addition. Be aware, that this intrinsic is flagged as 'sequence' by INTEL.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hadd<simd<int32_t, avx512>, Idof> {
            using Vec = simd<int32_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type value
            ) {
                return _mm512_reduce_add_epi32(value);
            }
        };
    } // end of namespace functors for template specialization of hadd for avx512 using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hadd" (primitive hadd).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::881
         * @note: Signed Addition. Be aware, that this intrinsic is flagged as 'sequence' by INTEL.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hadd<simd<int64_t, avx512>, Idof> {
            using Vec = simd<int64_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type value
            ) {
                return _mm512_reduce_add_epi64(value);
            }
        };
    } // end of namespace functors for template specialization of hadd for avx512 using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hadd" (primitive hadd).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::886
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hadd<simd<uint8_t, avx512>, Idof> {
            using Vec = simd<uint8_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type value
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive hadd is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer;
                typename Vec::base_type result = 0;
                _mm512_store_si512(reinterpret_cast<void*>(buffer.data()), value);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                    result += buffer[i];
                }
                return result;
            }
        };
    } // end of namespace functors for template specialization of hadd for avx512 using uint8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hadd" (primitive hadd).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::886
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hadd<simd<int8_t, avx512>, Idof> {
            using Vec = simd<int8_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type value
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive hadd is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer;
                typename Vec::base_type result = 0;
                _mm512_store_si512(reinterpret_cast<void*>(buffer.data()), value);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                    result += buffer[i];
                }
                return result;
            }
        };
    } // end of namespace functors for template specialization of hadd for avx512 using int8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hadd" (primitive hadd).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::886
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hadd<simd<uint16_t, avx512>, Idof> {
            using Vec = simd<uint16_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type value
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive hadd is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer;
                typename Vec::base_type result = 0;
                _mm512_store_si512(reinterpret_cast<void*>(buffer.data()), value);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                    result += buffer[i];
                }
                return result;
            }
        };
    } // end of namespace functors for template specialization of hadd for avx512 using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hadd" (primitive hadd).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::886
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hadd<simd<int16_t, avx512>, Idof> {
            using Vec = simd<int16_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type value
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive hadd is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer;
                typename Vec::base_type result = 0;
                _mm512_store_si512(reinterpret_cast<void*>(buffer.data()), value);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                    result += buffer[i];
                }
                return result;
            }
        };
    } // end of namespace functors for template specialization of hadd for avx512 using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "min" (primitive min).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1080
         * @note: Signed Min
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct min<simd<uint32_t, avx512>, Idof> {
            using Vec = simd<uint32_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_min_epu32(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of min for avx512 using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "min" (primitive min).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1080
         * @note: Signed Min
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct min<simd<uint64_t, avx512>, Idof> {
            using Vec = simd<uint64_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_min_epu64(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of min for avx512 using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "min" (primitive min).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1080
         * @note: Signed Min
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct min<simd<int32_t, avx512>, Idof> {
            using Vec = simd<int32_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_min_epi32(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of min for avx512 using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "min" (primitive min).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1080
         * @note: Signed Min
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct min<simd<int64_t, avx512>, Idof> {
            using Vec = simd<int64_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_min_epi64(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of min for avx512 using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "min" (primitive min).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1080
         * @note: Signed Min
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct min<simd<float, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_min_ps(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of min for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "min" (primitive min).
         * @details:
         * Target Extension: avx512.
         *        Data Type: double
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1080
         * @note: Signed Min
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct min<simd<double, avx512>, Idof> {
            using Vec = simd<double, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_min_pd(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of min for avx512 using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "div" (primitive div).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1232
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct div<simd<float, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_div_ps(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of div for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "div" (primitive div).
         * @details:
         * Target Extension: avx512.
         *        Data Type: double
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1232
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct div<simd<double, avx512>, Idof> {
            using Vec = simd<double, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_div_pd(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of div for avx512 using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "div" (primitive div).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1236
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct div<simd<uint8_t, avx512>, Idof> {
            using Vec = simd<uint8_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive div is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_a;
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_b;
                _mm512_store_si512(reinterpret_cast<void*>(buffer_a.data()), vec_a);
                _mm512_store_si512(reinterpret_cast<void*>(buffer_b.data()), vec_b);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                  buffer_a[i] /= buffer_b[i];
                }
                return _mm512_load_si512(reinterpret_cast<void const *>(buffer_a.data()));
            }
        };
    } // end of namespace functors for template specialization of div for avx512 using uint8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "div" (primitive div).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1236
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct div<simd<int8_t, avx512>, Idof> {
            using Vec = simd<int8_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive div is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_a;
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_b;
                _mm512_store_si512(reinterpret_cast<void*>(buffer_a.data()), vec_a);
                _mm512_store_si512(reinterpret_cast<void*>(buffer_b.data()), vec_b);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                  buffer_a[i] /= buffer_b[i];
                }
                return _mm512_load_si512(reinterpret_cast<void const *>(buffer_a.data()));
            }
        };
    } // end of namespace functors for template specialization of div for avx512 using int8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "div" (primitive div).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1236
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct div<simd<uint16_t, avx512>, Idof> {
            using Vec = simd<uint16_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive div is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_a;
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_b;
                _mm512_store_si512(reinterpret_cast<void*>(buffer_a.data()), vec_a);
                _mm512_store_si512(reinterpret_cast<void*>(buffer_b.data()), vec_b);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                  buffer_a[i] /= buffer_b[i];
                }
                return _mm512_load_si512(reinterpret_cast<void const *>(buffer_a.data()));
            }
        };
    } // end of namespace functors for template specialization of div for avx512 using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "div" (primitive div).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1236
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct div<simd<int16_t, avx512>, Idof> {
            using Vec = simd<int16_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive div is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_a;
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_b;
                _mm512_store_si512(reinterpret_cast<void*>(buffer_a.data()), vec_a);
                _mm512_store_si512(reinterpret_cast<void*>(buffer_b.data()), vec_b);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                  buffer_a[i] /= buffer_b[i];
                }
                return _mm512_load_si512(reinterpret_cast<void const *>(buffer_a.data()));
            }
        };
    } // end of namespace functors for template specialization of div for avx512 using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "div" (primitive div).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1236
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct div<simd<uint32_t, avx512>, Idof> {
            using Vec = simd<uint32_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive div is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_a;
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_b;
                _mm512_store_si512(reinterpret_cast<void*>(buffer_a.data()), vec_a);
                _mm512_store_si512(reinterpret_cast<void*>(buffer_b.data()), vec_b);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                  buffer_a[i] /= buffer_b[i];
                }
                return _mm512_load_si512(reinterpret_cast<void const *>(buffer_a.data()));
            }
        };
    } // end of namespace functors for template specialization of div for avx512 using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "div" (primitive div).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1236
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct div<simd<int32_t, avx512>, Idof> {
            using Vec = simd<int32_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive div is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_a;
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_b;
                _mm512_store_si512(reinterpret_cast<void*>(buffer_a.data()), vec_a);
                _mm512_store_si512(reinterpret_cast<void*>(buffer_b.data()), vec_b);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                  buffer_a[i] /= buffer_b[i];
                }
                return _mm512_load_si512(reinterpret_cast<void const *>(buffer_a.data()));
            }
        };
    } // end of namespace functors for template specialization of div for avx512 using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "div" (primitive div).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1236
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct div<simd<uint64_t, avx512>, Idof> {
            using Vec = simd<uint64_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive div is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_a;
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_b;
                _mm512_store_si512(reinterpret_cast<void*>(buffer_a.data()), vec_a);
                _mm512_store_si512(reinterpret_cast<void*>(buffer_b.data()), vec_b);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                  buffer_a[i] /= buffer_b[i];
                }
                return _mm512_load_si512(reinterpret_cast<void const *>(buffer_a.data()));
            }
        };
    } // end of namespace functors for template specialization of div for avx512 using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "div" (primitive div).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1236
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct div<simd<int64_t, avx512>, Idof> {
            using Vec = simd<int64_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive div is not supported by your hardware natively while it is forced by using native" );

                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_a;
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer_b;
                _mm512_store_si512(reinterpret_cast<void*>(buffer_a.data()), vec_a);
                _mm512_store_si512(reinterpret_cast<void*>(buffer_b.data()), vec_b);
                for(std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                  buffer_a[i] /= buffer_b[i];
                }
                return _mm512_load_si512(reinterpret_cast<void const *>(buffer_a.data()));
            }
        };
    } // end of namespace functors for template specialization of div for avx512 using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mod" (primitive mod).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1393
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mod<simd<uint8_t, avx512>, Idof> {
            using Vec = simd<uint8_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_data, const typename Vec::register_type vec_mod
            ) {
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer1;
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer2;
                _mm512_store_si512(reinterpret_cast<__m512i*>(buffer1.data()), vec_data);
                _mm512_store_si512(reinterpret_cast<__m512i*>(buffer2.data()), vec_mod);
                for (std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                  buffer1[i] = buffer1[i] % buffer2[i];
                }
                return _mm512_load_si512(reinterpret_cast<__m512i const*>(buffer1.data()));
            }
        };
    } // end of namespace functors for template specialization of mod for avx512 using uint8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mod" (primitive mod).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1393
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mod<simd<int8_t, avx512>, Idof> {
            using Vec = simd<int8_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_data, const typename Vec::register_type vec_mod
            ) {
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer1;
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer2;
                _mm512_store_si512(reinterpret_cast<__m512i*>(buffer1.data()), vec_data);
                _mm512_store_si512(reinterpret_cast<__m512i*>(buffer2.data()), vec_mod);
                for (std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                  buffer1[i] = buffer1[i] % buffer2[i];
                }
                return _mm512_load_si512(reinterpret_cast<__m512i const*>(buffer1.data()));
            }
        };
    } // end of namespace functors for template specialization of mod for avx512 using int8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mod" (primitive mod).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1393
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mod<simd<uint16_t, avx512>, Idof> {
            using Vec = simd<uint16_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_data, const typename Vec::register_type vec_mod
            ) {
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer1;
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer2;
                _mm512_store_si512(reinterpret_cast<__m512i*>(buffer1.data()), vec_data);
                _mm512_store_si512(reinterpret_cast<__m512i*>(buffer2.data()), vec_mod);
                for (std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                  buffer1[i] = buffer1[i] % buffer2[i];
                }
                return _mm512_load_si512(reinterpret_cast<__m512i const*>(buffer1.data()));
            }
        };
    } // end of namespace functors for template specialization of mod for avx512 using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mod" (primitive mod).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1393
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mod<simd<int16_t, avx512>, Idof> {
            using Vec = simd<int16_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_data, const typename Vec::register_type vec_mod
            ) {
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer1;
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer2;
                _mm512_store_si512(reinterpret_cast<__m512i*>(buffer1.data()), vec_data);
                _mm512_store_si512(reinterpret_cast<__m512i*>(buffer2.data()), vec_mod);
                for (std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                  buffer1[i] = buffer1[i] % buffer2[i];
                }
                return _mm512_load_si512(reinterpret_cast<__m512i const*>(buffer1.data()));
            }
        };
    } // end of namespace functors for template specialization of mod for avx512 using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mod" (primitive mod).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1406
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mod<simd<int32_t, avx512>, Idof> {
            using Vec = simd<int32_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_data, const typename Vec::register_type vec_mod
            ) {
                using T = float;

                __m512 vec_d = tsl::cast<Vec, typename Vec::template transform_extension<T>>(vec_data);
                __m512 val_d = tsl::cast<Vec, typename Vec::template transform_extension<T>>(vec_mod);

                __m512 temp = tsl::div<typename Vec::template transform_extension<T>>(vec_d, val_d);
                temp = _mm512_roundscale_ps(temp, _MM_FROUND_TO_ZERO);
                temp = _mm512_mul_ps(temp, val_d);
                temp = _mm512_sub_ps(vec_d, temp);

                return tsl::cast<typename Vec::template transform_extension<T>,Vec>(temp);
            }
        };
    } // end of namespace functors for template specialization of mod for avx512 using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mod" (primitive mod).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1406
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mod<simd<uint32_t, avx512>, Idof> {
            using Vec = simd<uint32_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_data, const typename Vec::register_type vec_mod
            ) {
                using T = float;

                __m512 vec_d = tsl::cast<Vec, typename Vec::template transform_extension<T>>(vec_data);
                __m512 val_d = tsl::cast<Vec, typename Vec::template transform_extension<T>>(vec_mod);

                __m512 temp = tsl::div<typename Vec::template transform_extension<T>>(vec_d, val_d);
                temp = _mm512_roundscale_ps(temp, _MM_FROUND_TO_ZERO);
                temp = _mm512_mul_ps(temp, val_d);
                temp = _mm512_sub_ps(vec_d, temp);

                return tsl::cast<typename Vec::template transform_extension<T>,Vec>(temp);
            }
        };
    } // end of namespace functors for template specialization of mod for avx512 using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mod_constant" (primitive mod).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1630
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mod_constant<simd<uint8_t, avx512>, Idof> {
            using Vec = simd<uint8_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec, const typename Vec::base_type val
            ) {
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer;
                _mm512_store_si512(reinterpret_cast<__m512i*>(buffer.data()), vec);
                for (std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                  buffer[i] = buffer[i] % val;
                }
                return _mm512_load_si512(reinterpret_cast<__m512i const*>(buffer.data()));
            }
        };
    } // end of namespace functors for template specialization of mod_constant for avx512 using uint8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mod_constant" (primitive mod).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1630
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mod_constant<simd<int8_t, avx512>, Idof> {
            using Vec = simd<int8_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec, const typename Vec::base_type val
            ) {
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer;
                _mm512_store_si512(reinterpret_cast<__m512i*>(buffer.data()), vec);
                for (std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                  buffer[i] = buffer[i] % val;
                }
                return _mm512_load_si512(reinterpret_cast<__m512i const*>(buffer.data()));
            }
        };
    } // end of namespace functors for template specialization of mod_constant for avx512 using int8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mod_constant" (primitive mod).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1630
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mod_constant<simd<uint16_t, avx512>, Idof> {
            using Vec = simd<uint16_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec, const typename Vec::base_type val
            ) {
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer;
                _mm512_store_si512(reinterpret_cast<__m512i*>(buffer.data()), vec);
                for (std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                  buffer[i] = buffer[i] % val;
                }
                return _mm512_load_si512(reinterpret_cast<__m512i const*>(buffer.data()));
            }
        };
    } // end of namespace functors for template specialization of mod_constant for avx512 using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mod_constant" (primitive mod).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1630
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mod_constant<simd<int16_t, avx512>, Idof> {
            using Vec = simd<int16_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec, const typename Vec::base_type val
            ) {
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer;
                _mm512_store_si512(reinterpret_cast<__m512i*>(buffer.data()), vec);
                for (std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                  buffer[i] = buffer[i] % val;
                }
                return _mm512_load_si512(reinterpret_cast<__m512i const*>(buffer.data()));
            }
        };
    } // end of namespace functors for template specialization of mod_constant for avx512 using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mod_constant" (primitive mod).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1641
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mod_constant<simd<int32_t, avx512>, Idof> {
            using Vec = simd<int32_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec, const typename Vec::base_type val
            ) {
                using T = float;

                __m512 vec_d = tsl::cast<Vec, typename Vec::template transform_extension<T>>(vec);
                __m512 val_d = _mm512_set1_ps(static_cast<T>(val));

                __m512 temp = tsl::div<typename Vec::template transform_extension<T>>(vec_d, val_d);
                temp = _mm512_roundscale_ps(temp, _MM_FROUND_TO_ZERO);
                temp = _mm512_mul_ps(temp, val_d);
                temp = _mm512_sub_ps(vec_d, temp);

                return tsl::cast<typename Vec::template transform_extension<T>,Vec>(temp);
            }
        };
    } // end of namespace functors for template specialization of mod_constant for avx512 using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mod_constant" (primitive mod).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1641
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mod_constant<simd<uint32_t, avx512>, Idof> {
            using Vec = simd<uint32_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec, const typename Vec::base_type val
            ) {
                using T = float;

                __m512 vec_d = tsl::cast<Vec, typename Vec::template transform_extension<T>>(vec);
                __m512 val_d = _mm512_set1_ps(static_cast<T>(val));

                __m512 temp = tsl::div<typename Vec::template transform_extension<T>>(vec_d, val_d);
                temp = _mm512_roundscale_ps(temp, _MM_FROUND_TO_ZERO);
                temp = _mm512_mul_ps(temp, val_d);
                temp = _mm512_sub_ps(vec_d, temp);

                return tsl::cast<typename Vec::template transform_extension<T>,Vec>(temp);
            }
        };
    } // end of namespace functors for template specialization of mod_constant for avx512 using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mod_safe" (primitive mod_safe).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1870
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mod_safe<simd<uint8_t, avx512>, Idof> {
            using Vec = simd<uint8_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec, const typename Vec::base_type val
            ) {
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer;
                _mm512_store_si512(reinterpret_cast<__m512i*>(buffer.data()), vec);
                for (std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                  buffer[i] = buffer[i] % val;
                }
                return _mm512_load_si512(reinterpret_cast<__m512i const*>(buffer.data()));
            }
        };
    } // end of namespace functors for template specialization of mod_safe for avx512 using uint8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mod_safe" (primitive mod_safe).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1870
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mod_safe<simd<int8_t, avx512>, Idof> {
            using Vec = simd<int8_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec, const typename Vec::base_type val
            ) {
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer;
                _mm512_store_si512(reinterpret_cast<__m512i*>(buffer.data()), vec);
                for (std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                  buffer[i] = buffer[i] % val;
                }
                return _mm512_load_si512(reinterpret_cast<__m512i const*>(buffer.data()));
            }
        };
    } // end of namespace functors for template specialization of mod_safe for avx512 using int8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mod_safe" (primitive mod_safe).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1870
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mod_safe<simd<uint16_t, avx512>, Idof> {
            using Vec = simd<uint16_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec, const typename Vec::base_type val
            ) {
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer;
                _mm512_store_si512(reinterpret_cast<__m512i*>(buffer.data()), vec);
                for (std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                  buffer[i] = buffer[i] % val;
                }
                return _mm512_load_si512(reinterpret_cast<__m512i const*>(buffer.data()));
            }
        };
    } // end of namespace functors for template specialization of mod_safe for avx512 using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mod_safe" (primitive mod_safe).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1870
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mod_safe<simd<int16_t, avx512>, Idof> {
            using Vec = simd<int16_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec, const typename Vec::base_type val
            ) {
                alignas(Vec::vector_alignment()) std::array<typename Vec::base_type, Vec::vector_element_count()> buffer;
                _mm512_store_si512(reinterpret_cast<__m512i*>(buffer.data()), vec);
                for (std::size_t i = 0; i < Vec::vector_element_count(); ++i) {
                  buffer[i] = buffer[i] % val;
                }
                return _mm512_load_si512(reinterpret_cast<__m512i const*>(buffer.data()));
            }
        };
    } // end of namespace functors for template specialization of mod_safe for avx512 using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mod_safe" (primitive mod_safe).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1881
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mod_safe<simd<int32_t, avx512>, Idof> {
            using Vec = simd<int32_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec, const typename Vec::base_type val
            ) {
                using T = float;
                int threshold_value = 16777216;
                auto threshold = _mm512_set1_epi32(threshold_value);
                auto cmp_result = _mm512_cmpgt_epi32_mask(vec, threshold);
                if(cmp_result){
                  auto arr = tsl::to_array<Vec>(vec);
                  typename Vec::base_type result[Vec::vector_element_count()];
                  for(int i = 0; i < Vec::vector_element_count(); i++){
                    result[i] = arr[i] % val;
                  }
                  return tsl::loadu<Vec>(result);
                }else{
                  __m512 vec_d = tsl::cast<Vec, typename Vec::template transform_extension<T>>(vec);
                  __m512 val_d = _mm512_set1_ps(static_cast<T>(val));

                  __m512 temp = tsl::div<typename Vec::template transform_extension<T>>(vec_d, val_d);
                  temp = _mm512_roundscale_ps(temp, _MM_FROUND_TO_ZERO);
                  temp = _mm512_mul_ps(temp, val_d);
                  temp = _mm512_sub_ps(vec_d, temp);

                  return tsl::cast<typename Vec::template transform_extension<T>,Vec>(temp);
                }
            }
        };
    } // end of namespace functors for template specialization of mod_safe for avx512 using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mod_safe" (primitive mod_safe).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::1881
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mod_safe<simd<uint32_t, avx512>, Idof> {
            using Vec = simd<uint32_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::base_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec, const typename Vec::base_type val
            ) {
                using T = float;
                int threshold_value = 16777216;
                auto threshold = _mm512_set1_epi32(threshold_value);
                auto cmp_result = _mm512_cmpgt_epi32_mask(vec, threshold);
                if(cmp_result){
                  auto arr = tsl::to_array<Vec>(vec);
                  typename Vec::base_type result[Vec::vector_element_count()];
                  for(int i = 0; i < Vec::vector_element_count(); i++){
                    result[i] = arr[i] % val;
                  }
                  return tsl::loadu<Vec>(result);
                }else{
                  __m512 vec_d = tsl::cast<Vec, typename Vec::template transform_extension<T>>(vec);
                  __m512 val_d = _mm512_set1_ps(static_cast<T>(val));

                  __m512 temp = tsl::div<typename Vec::template transform_extension<T>>(vec_d, val_d);
                  temp = _mm512_roundscale_ps(temp, _MM_FROUND_TO_ZERO);
                  temp = _mm512_mul_ps(temp, val_d);
                  temp = _mm512_sub_ps(vec_d, temp);

                  return tsl::cast<typename Vec::template transform_extension<T>,Vec>(temp);
                }
            }
        };
    } // end of namespace functors for template specialization of mod_safe for avx512 using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hmax" (primitive hmax).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2084
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hmax<simd<uint32_t, avx512>, Idof> {
            using Vec = simd<uint32_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_reduce_max_epu32(data);
            }
        };
    } // end of namespace functors for template specialization of hmax for avx512 using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hmax" (primitive hmax).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2084
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hmax<simd<int32_t, avx512>, Idof> {
            using Vec = simd<int32_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_reduce_max_epi32(data);
            }
        };
    } // end of namespace functors for template specialization of hmax for avx512 using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hmax" (primitive hmax).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2084
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hmax<simd<uint64_t, avx512>, Idof> {
            using Vec = simd<uint64_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_reduce_max_epu64(data);
            }
        };
    } // end of namespace functors for template specialization of hmax for avx512 using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hmax" (primitive hmax).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2084
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hmax<simd<int64_t, avx512>, Idof> {
            using Vec = simd<int64_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_reduce_max_epi64(data);
            }
        };
    } // end of namespace functors for template specialization of hmax for avx512 using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hmax" (primitive hmax).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2084
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hmax<simd<float, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_reduce_max_ps(data);
            }
        };
    } // end of namespace functors for template specialization of hmax for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hmax" (primitive hmax).
         * @details:
         * Target Extension: avx512.
         *        Data Type: double
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2084
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hmax<simd<double, avx512>, Idof> {
            using Vec = simd<double, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_reduce_max_pd(data);
            }
        };
    } // end of namespace functors for template specialization of hmax for avx512 using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hmax" (primitive hmax).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2088
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hmax<simd<uint8_t, avx512>, Idof> {
            using Vec = simd<uint8_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type data
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive hmax is not supported by your hardware natively while it is forced by using native" );

                auto arr = tsl::to_array<Vec>(data);
                return *std::max_element(arr.begin(), arr.end());
            }
        };
    } // end of namespace functors for template specialization of hmax for avx512 using uint8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hmax" (primitive hmax).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2088
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hmax<simd<int8_t, avx512>, Idof> {
            using Vec = simd<int8_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type data
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive hmax is not supported by your hardware natively while it is forced by using native" );

                auto arr = tsl::to_array<Vec>(data);
                return *std::max_element(arr.begin(), arr.end());
            }
        };
    } // end of namespace functors for template specialization of hmax for avx512 using int8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hmax" (primitive hmax).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2088
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hmax<simd<uint16_t, avx512>, Idof> {
            using Vec = simd<uint16_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type data
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive hmax is not supported by your hardware natively while it is forced by using native" );

                auto arr = tsl::to_array<Vec>(data);
                return *std::max_element(arr.begin(), arr.end());
            }
        };
    } // end of namespace functors for template specialization of hmax for avx512 using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hmax" (primitive hmax).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2088
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hmax<simd<int16_t, avx512>, Idof> {
            using Vec = simd<int16_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type data
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive hmax is not supported by your hardware natively while it is forced by using native" );

                auto arr = tsl::to_array<Vec>(data);
                return *std::max_element(arr.begin(), arr.end());
            }
        };
    } // end of namespace functors for template specialization of hmax for avx512 using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hmin" (primitive hmin).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2252
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hmin<simd<uint32_t, avx512>, Idof> {
            using Vec = simd<uint32_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_reduce_min_epu32(data);
            }
        };
    } // end of namespace functors for template specialization of hmin for avx512 using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hmin" (primitive hmin).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2252
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hmin<simd<int32_t, avx512>, Idof> {
            using Vec = simd<int32_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_reduce_min_epi32(data);
            }
        };
    } // end of namespace functors for template specialization of hmin for avx512 using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hmin" (primitive hmin).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2252
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hmin<simd<uint64_t, avx512>, Idof> {
            using Vec = simd<uint64_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_reduce_min_epu64(data);
            }
        };
    } // end of namespace functors for template specialization of hmin for avx512 using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hmin" (primitive hmin).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2252
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hmin<simd<int64_t, avx512>, Idof> {
            using Vec = simd<int64_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_reduce_min_epi64(data);
            }
        };
    } // end of namespace functors for template specialization of hmin for avx512 using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hmin" (primitive hmin).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2252
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hmin<simd<float, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_reduce_min_ps(data);
            }
        };
    } // end of namespace functors for template specialization of hmin for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hmin" (primitive hmin).
         * @details:
         * Target Extension: avx512.
         *        Data Type: double
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2252
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hmin<simd<double, avx512>, Idof> {
            using Vec = simd<double, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_reduce_min_pd(data);
            }
        };
    } // end of namespace functors for template specialization of hmin for avx512 using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hmin" (primitive hmin).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2256
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hmin<simd<uint8_t, avx512>, Idof> {
            using Vec = simd<uint8_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type data
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive hmin is not supported by your hardware natively while it is forced by using native" );

                auto arr = tsl::to_array<Vec>(data);
                return *std::min_element(arr.begin(), arr.end());
            }
        };
    } // end of namespace functors for template specialization of hmin for avx512 using uint8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hmin" (primitive hmin).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2256
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hmin<simd<int8_t, avx512>, Idof> {
            using Vec = simd<int8_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type data
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive hmin is not supported by your hardware natively while it is forced by using native" );

                auto arr = tsl::to_array<Vec>(data);
                return *std::min_element(arr.begin(), arr.end());
            }
        };
    } // end of namespace functors for template specialization of hmin for avx512 using int8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hmin" (primitive hmin).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2256
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hmin<simd<uint16_t, avx512>, Idof> {
            using Vec = simd<uint16_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type data
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive hmin is not supported by your hardware natively while it is forced by using native" );

                auto arr = tsl::to_array<Vec>(data);
                return *std::min_element(arr.begin(), arr.end());
            }
        };
    } // end of namespace functors for template specialization of hmin for avx512 using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "hmin" (primitive hmin).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2256
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct hmin<simd<int16_t, avx512>, Idof> {
            using Vec = simd<int16_t, avx512>;
            
            using return_type = typename Vec::base_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return false;
            }
            [[nodiscard]] TSL_NO_NATIVE_SUPPORT_WARNING
            TSL_FORCE_INLINE 
            static typename Vec::base_type apply(
                const typename Vec::register_type data
            ) {
                static_assert( !std::is_same_v< Idof, native >, "The primitive hmin is not supported by your hardware natively while it is forced by using native" );

                auto arr = tsl::to_array<Vec>(data);
                return *std::min_element(arr.begin(), arr.end());
            }
        };
    } // end of namespace functors for template specialization of hmin for avx512 using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "max" (primitive max).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2430
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct max<simd<uint32_t, avx512>, Idof> {
            using Vec = simd<uint32_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_max_epu32(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of max for avx512 using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "max" (primitive max).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2430
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct max<simd<int32_t, avx512>, Idof> {
            using Vec = simd<int32_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_max_epi32(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of max for avx512 using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "max" (primitive max).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2430
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct max<simd<float, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_max_ps(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of max for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "max" (primitive max).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2430
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct max<simd<uint64_t, avx512>, Idof> {
            using Vec = simd<uint64_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_max_epu64(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of max for avx512 using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "max" (primitive max).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2430
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct max<simd<int64_t, avx512>, Idof> {
            using Vec = simd<int64_t, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_max_epi64(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of max for avx512 using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "max" (primitive max).
         * @details:
         * Target Extension: avx512.
         *        Data Type: double
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/calc.yaml::2430
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct max<simd<double, avx512>, Idof> {
            using Vec = simd<double, avx512>;
            
            using return_type = typename Vec::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::register_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm512_max_pd(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of max for avx512 using double.

} // end of namespace tsl
#endif //TUD_D2RG_TSL_GITHUB_WORKSPACE_CI_GENERATION_SSE_SSE2_SSSE3_SSE4_1_SSE4_2_AVX_AVX2_AVX512F_INCLUDE_GENERATED_DEFINITIONS_CALC_CALC_AVX512_HPP