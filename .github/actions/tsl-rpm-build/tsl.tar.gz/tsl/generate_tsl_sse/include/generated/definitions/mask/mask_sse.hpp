/*==========================================================================*
 * This file is part of the TSL - a template SIMD library.                  *
 *                                                                          *
 * Copyright 2024 TSL-Team, Database Research Group TU Dresden              *
 *                                                                          *
 * Licensed under the Apache License, Version 2.0 (the "License");          *
 * you may not use this file except in compliance with the License.         *
 * You may obtain a copy of the License at                                  *
 *                                                                          *
 *     http://www.apache.org/licenses/LICENSE-2.0                           *
 *                                                                          *
 * Unless required by applicable law or agreed to in writing, software      *
 * distributed under the License is distributed on an "AS IS" BASIS,        *
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. *
 * See the License for the specific language governing permissions and      *
 * limitations under the License.                                           *
 *==========================================================================*/
/*
 * \file /github/workspace/ci/generation/sse/include/generated/definitions/mask/mask_sse.hpp
 * \date 2024-03-05
 * \brief Mask related primitives.
 * \note
 * Git-Local Url : /github/workspace
 * Git-Remote Url: unknown url
 * Git-Branch    : unknown branch
 * Git-Commit    : unknown commit (unknown commit)
 *
 */
#ifndef TUD_D2RG_TSL_GITHUB_WORKSPACE_CI_GENERATION_SSE_INCLUDE_GENERATED_DEFINITIONS_MASK_MASK_SSE_HPP
#define TUD_D2RG_TSL_GITHUB_WORKSPACE_CI_GENERATION_SSE_INCLUDE_GENERATED_DEFINITIONS_MASK_MASK_SSE_HPP

#include <type_traits>
#include "../../declarations/mask.hpp"
#include <tuple>

namespace tsl {

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "to_integral" (primitive to_integral).
         * @details:
         * Target Extension: sse.
         *        Data Type: float
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::182
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct to_integral<simd<float, sse>, Idof> {
            using Vec = simd<float, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<const typename Vec::mask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                const typename Vec::mask_type vec_mask
            ) {
                return _mm_movemask_ps(vec_mask);
            }
        };
    } // end of namespace functors for template specialization of to_integral for sse using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "imask_binary_not" (primitive mask_binary_not).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint8_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::517
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct imask_binary_not<simd<uint8_t, sse>, Idof> {
            using Vec = simd<uint8_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                const typename Vec::imask_type mask
            ) {
                return (~mask);
            }
        };
    } // end of namespace functors for template specialization of imask_binary_not for sse using uint8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "imask_binary_not" (primitive mask_binary_not).
         * @details:
         * Target Extension: sse.
         *        Data Type: int8_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::517
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct imask_binary_not<simd<int8_t, sse>, Idof> {
            using Vec = simd<int8_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                const typename Vec::imask_type mask
            ) {
                return (~mask);
            }
        };
    } // end of namespace functors for template specialization of imask_binary_not for sse using int8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "imask_binary_not" (primitive mask_binary_not).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint16_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::517
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct imask_binary_not<simd<uint16_t, sse>, Idof> {
            using Vec = simd<uint16_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                const typename Vec::imask_type mask
            ) {
                return (~mask);
            }
        };
    } // end of namespace functors for template specialization of imask_binary_not for sse using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "imask_binary_not" (primitive mask_binary_not).
         * @details:
         * Target Extension: sse.
         *        Data Type: int16_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::517
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct imask_binary_not<simd<int16_t, sse>, Idof> {
            using Vec = simd<int16_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                const typename Vec::imask_type mask
            ) {
                return (~mask);
            }
        };
    } // end of namespace functors for template specialization of imask_binary_not for sse using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "imask_binary_not" (primitive mask_binary_not).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint32_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::521
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct imask_binary_not<simd<uint32_t, sse>, Idof> {
            using Vec = simd<uint32_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                const typename Vec::imask_type mask
            ) {
                return (~mask)&(0b1111);
            }
        };
    } // end of namespace functors for template specialization of imask_binary_not for sse using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "imask_binary_not" (primitive mask_binary_not).
         * @details:
         * Target Extension: sse.
         *        Data Type: int32_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::521
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct imask_binary_not<simd<int32_t, sse>, Idof> {
            using Vec = simd<int32_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                const typename Vec::imask_type mask
            ) {
                return (~mask)&(0b1111);
            }
        };
    } // end of namespace functors for template specialization of imask_binary_not for sse using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "imask_binary_not" (primitive mask_binary_not).
         * @details:
         * Target Extension: sse.
         *        Data Type: float
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::521
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct imask_binary_not<simd<float, sse>, Idof> {
            using Vec = simd<float, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                const typename Vec::imask_type mask
            ) {
                return (~mask)&(0b1111);
            }
        };
    } // end of namespace functors for template specialization of imask_binary_not for sse using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "imask_binary_not" (primitive mask_binary_not).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint64_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::525
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct imask_binary_not<simd<uint64_t, sse>, Idof> {
            using Vec = simd<uint64_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                const typename Vec::imask_type mask
            ) {
                return (~mask)&(0b11);
            }
        };
    } // end of namespace functors for template specialization of imask_binary_not for sse using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "imask_binary_not" (primitive mask_binary_not).
         * @details:
         * Target Extension: sse.
         *        Data Type: int64_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::525
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct imask_binary_not<simd<int64_t, sse>, Idof> {
            using Vec = simd<int64_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                const typename Vec::imask_type mask
            ) {
                return (~mask)&(0b11);
            }
        };
    } // end of namespace functors for template specialization of imask_binary_not for sse using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "imask_binary_not" (primitive mask_binary_not).
         * @details:
         * Target Extension: sse.
         *        Data Type: double
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::525
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct imask_binary_not<simd<double, sse>, Idof> {
            using Vec = simd<double, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                const typename Vec::imask_type mask
            ) {
                return (~mask)&(0b11);
            }
        };
    } // end of namespace functors for template specialization of imask_binary_not for sse using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mask_binary_and" (primitive mask_binary_and).
         * @details:
         * Target Extension: sse.
         *        Data Type: float
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::607
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mask_binary_and<simd<float, sse>, Idof> {
            using Vec = simd<float, sse>;
            
            using return_type = typename Vec::mask_type;
            using param_tuple_t = std::tuple<const typename Vec::mask_type, const typename Vec::mask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::mask_type apply(
                const typename Vec::mask_type first, const typename Vec::mask_type second
            ) {
                return _mm_and_ps(first, second);
            }
        };
    } // end of namespace functors for template specialization of mask_binary_and for sse using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mask_binary_or" (primitive mask_binary_or).
         * @details:
         * Target Extension: sse.
         *        Data Type: float
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::713
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mask_binary_or<simd<float, sse>, Idof> {
            using Vec = simd<float, sse>;
            
            using return_type = typename Vec::mask_type;
            using param_tuple_t = std::tuple<const typename Vec::mask_type, const typename Vec::mask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::mask_type apply(
                const typename Vec::mask_type first, const typename Vec::mask_type second
            ) {
                return _mm_or_ps(first, second);
            }
        };
    } // end of namespace functors for template specialization of mask_binary_or for sse using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "mask_binary_xor" (primitive mask_binary_xor).
         * @details:
         * Target Extension: sse.
         *        Data Type: float
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::809
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct mask_binary_xor<simd<float, sse>, Idof> {
            using Vec = simd<float, sse>;
            
            using return_type = typename Vec::mask_type;
            using param_tuple_t = std::tuple<const typename Vec::mask_type, const typename Vec::mask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::mask_type apply(
                const typename Vec::mask_type first, const typename Vec::mask_type second
            ) {
                return _mm_xor_ps(first, second);
            }
        };
    } // end of namespace functors for template specialization of mask_binary_xor for sse using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "imask_population_count" (primitive mask_population_count).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint8_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::988
         * @note: TODO: actual value is smaller than the type for u/int16. Pls check.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct imask_population_count<simd<uint8_t, sse>, Idof> {
            using Vec = simd<uint8_t, sse>;
            
            using return_type = unsigned int;
            using param_tuple_t = std::tuple<const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static unsigned int apply(
                const typename Vec::imask_type mask
            ) {
                #if defined(__clang__) || defined(__GNUC__)
                return __builtin_popcount(mask);
                #elif defined(_MSC_VER)
                return  __popcnt16(mask);
                #else
                static_assert(false, "No known implementation for popcount");
                #endif
            }
        };
    } // end of namespace functors for template specialization of imask_population_count for sse using uint8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "imask_population_count" (primitive mask_population_count).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint16_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::988
         * @note: TODO: actual value is smaller than the type for u/int16. Pls check.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct imask_population_count<simd<uint16_t, sse>, Idof> {
            using Vec = simd<uint16_t, sse>;
            
            using return_type = unsigned int;
            using param_tuple_t = std::tuple<const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static unsigned int apply(
                const typename Vec::imask_type mask
            ) {
                #if defined(__clang__) || defined(__GNUC__)
                return __builtin_popcount(mask);
                #elif defined(_MSC_VER)
                return  __popcnt16(mask);
                #else
                static_assert(false, "No known implementation for popcount");
                #endif
            }
        };
    } // end of namespace functors for template specialization of imask_population_count for sse using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "imask_population_count" (primitive mask_population_count).
         * @details:
         * Target Extension: sse.
         *        Data Type: int8_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::988
         * @note: TODO: actual value is smaller than the type for u/int16. Pls check.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct imask_population_count<simd<int8_t, sse>, Idof> {
            using Vec = simd<int8_t, sse>;
            
            using return_type = unsigned int;
            using param_tuple_t = std::tuple<const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static unsigned int apply(
                const typename Vec::imask_type mask
            ) {
                #if defined(__clang__) || defined(__GNUC__)
                return __builtin_popcount(mask);
                #elif defined(_MSC_VER)
                return  __popcnt16(mask);
                #else
                static_assert(false, "No known implementation for popcount");
                #endif
            }
        };
    } // end of namespace functors for template specialization of imask_population_count for sse using int8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "imask_population_count" (primitive mask_population_count).
         * @details:
         * Target Extension: sse.
         *        Data Type: int16_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::988
         * @note: TODO: actual value is smaller than the type for u/int16. Pls check.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct imask_population_count<simd<int16_t, sse>, Idof> {
            using Vec = simd<int16_t, sse>;
            
            using return_type = unsigned int;
            using param_tuple_t = std::tuple<const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static unsigned int apply(
                const typename Vec::imask_type mask
            ) {
                #if defined(__clang__) || defined(__GNUC__)
                return __builtin_popcount(mask);
                #elif defined(_MSC_VER)
                return  __popcnt16(mask);
                #else
                static_assert(false, "No known implementation for popcount");
                #endif
            }
        };
    } // end of namespace functors for template specialization of imask_population_count for sse using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "imask_population_count" (primitive mask_population_count).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint32_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1000
         * @note: TODO: actual value is smaller than the type. Pls check.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct imask_population_count<simd<uint32_t, sse>, Idof> {
            using Vec = simd<uint32_t, sse>;
            
            using return_type = unsigned int;
            using param_tuple_t = std::tuple<const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static unsigned int apply(
                const typename Vec::imask_type mask
            ) {
                #if defined(__clang__) || defined(__GNUC__)
                return __builtin_popcountl(mask);
                #elif defined(_MSC_VER)
                return  __popcnt32(mask);
                #else
                static_assert(false, "No known implementation for popcount");
                #endif
            }
        };
    } // end of namespace functors for template specialization of imask_population_count for sse using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "imask_population_count" (primitive mask_population_count).
         * @details:
         * Target Extension: sse.
         *        Data Type: int32_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1000
         * @note: TODO: actual value is smaller than the type. Pls check.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct imask_population_count<simd<int32_t, sse>, Idof> {
            using Vec = simd<int32_t, sse>;
            
            using return_type = unsigned int;
            using param_tuple_t = std::tuple<const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static unsigned int apply(
                const typename Vec::imask_type mask
            ) {
                #if defined(__clang__) || defined(__GNUC__)
                return __builtin_popcountl(mask);
                #elif defined(_MSC_VER)
                return  __popcnt32(mask);
                #else
                static_assert(false, "No known implementation for popcount");
                #endif
            }
        };
    } // end of namespace functors for template specialization of imask_population_count for sse using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "imask_population_count" (primitive mask_population_count).
         * @details:
         * Target Extension: sse.
         *        Data Type: float
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1000
         * @note: TODO: actual value is smaller than the type. Pls check.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct imask_population_count<simd<float, sse>, Idof> {
            using Vec = simd<float, sse>;
            
            using return_type = unsigned int;
            using param_tuple_t = std::tuple<const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static unsigned int apply(
                const typename Vec::imask_type mask
            ) {
                #if defined(__clang__) || defined(__GNUC__)
                return __builtin_popcountl(mask);
                #elif defined(_MSC_VER)
                return  __popcnt32(mask);
                #else
                static_assert(false, "No known implementation for popcount");
                #endif
            }
        };
    } // end of namespace functors for template specialization of imask_population_count for sse using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "imask_population_count" (primitive mask_population_count).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint64_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1012
         * @note: TODO: actual value is smaller than the type. Pls check.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct imask_population_count<simd<uint64_t, sse>, Idof> {
            using Vec = simd<uint64_t, sse>;
            
            using return_type = unsigned int;
            using param_tuple_t = std::tuple<const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static unsigned int apply(
                const typename Vec::imask_type mask
            ) {
                #if defined(__clang__) || defined(__GNUC__)
                return __builtin_popcountll(mask);
                #elif defined(_MSC_VER)
                return  __popcnt64(mask);
                #else
                static_assert(false, "No known implementation for popcount");
                #endif
            }
        };
    } // end of namespace functors for template specialization of imask_population_count for sse using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "imask_population_count" (primitive mask_population_count).
         * @details:
         * Target Extension: sse.
         *        Data Type: int64_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1012
         * @note: TODO: actual value is smaller than the type. Pls check.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct imask_population_count<simd<int64_t, sse>, Idof> {
            using Vec = simd<int64_t, sse>;
            
            using return_type = unsigned int;
            using param_tuple_t = std::tuple<const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static unsigned int apply(
                const typename Vec::imask_type mask
            ) {
                #if defined(__clang__) || defined(__GNUC__)
                return __builtin_popcountll(mask);
                #elif defined(_MSC_VER)
                return  __popcnt64(mask);
                #else
                static_assert(false, "No known implementation for popcount");
                #endif
            }
        };
    } // end of namespace functors for template specialization of imask_population_count for sse using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "imask_population_count" (primitive mask_population_count).
         * @details:
         * Target Extension: sse.
         *        Data Type: double
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1012
         * @note: TODO: actual value is smaller than the type. Pls check.
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct imask_population_count<simd<double, sse>, Idof> {
            using Vec = simd<double, sse>;
            
            using return_type = unsigned int;
            using param_tuple_t = std::tuple<const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static unsigned int apply(
                const typename Vec::imask_type mask
            ) {
                #if defined(__clang__) || defined(__GNUC__)
                return __builtin_popcountll(mask);
                #elif defined(_MSC_VER)
                return  __popcnt64(mask);
                #else
                static_assert(false, "No known implementation for popcount");
                #endif
            }
        };
    } // end of namespace functors for template specialization of imask_population_count for sse using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "integral_all_true" (primitive integral_all_true).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint8_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1054
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct integral_all_true<simd<uint8_t, sse>, Idof> {
            using Vec = simd<uint8_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                
            ) {
                if constexpr(Vec::vector_element_count() < 8) {
                  return ((static_cast<typename Vec::imask_type>(1)<<Vec::vector_element_count()) - 1);
                } else {
                  return ~0;
                }
            }
        };
    } // end of namespace functors for template specialization of integral_all_true for sse using uint8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "integral_all_true" (primitive integral_all_true).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint16_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1054
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct integral_all_true<simd<uint16_t, sse>, Idof> {
            using Vec = simd<uint16_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                
            ) {
                if constexpr(Vec::vector_element_count() < 8) {
                  return ((static_cast<typename Vec::imask_type>(1)<<Vec::vector_element_count()) - 1);
                } else {
                  return ~0;
                }
            }
        };
    } // end of namespace functors for template specialization of integral_all_true for sse using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "integral_all_true" (primitive integral_all_true).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint32_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1054
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct integral_all_true<simd<uint32_t, sse>, Idof> {
            using Vec = simd<uint32_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                
            ) {
                if constexpr(Vec::vector_element_count() < 8) {
                  return ((static_cast<typename Vec::imask_type>(1)<<Vec::vector_element_count()) - 1);
                } else {
                  return ~0;
                }
            }
        };
    } // end of namespace functors for template specialization of integral_all_true for sse using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "integral_all_true" (primitive integral_all_true).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint64_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1054
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct integral_all_true<simd<uint64_t, sse>, Idof> {
            using Vec = simd<uint64_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                
            ) {
                if constexpr(Vec::vector_element_count() < 8) {
                  return ((static_cast<typename Vec::imask_type>(1)<<Vec::vector_element_count()) - 1);
                } else {
                  return ~0;
                }
            }
        };
    } // end of namespace functors for template specialization of integral_all_true for sse using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "integral_all_true" (primitive integral_all_true).
         * @details:
         * Target Extension: sse.
         *        Data Type: int8_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1054
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct integral_all_true<simd<int8_t, sse>, Idof> {
            using Vec = simd<int8_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                
            ) {
                if constexpr(Vec::vector_element_count() < 8) {
                  return ((static_cast<typename Vec::imask_type>(1)<<Vec::vector_element_count()) - 1);
                } else {
                  return ~0;
                }
            }
        };
    } // end of namespace functors for template specialization of integral_all_true for sse using int8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "integral_all_true" (primitive integral_all_true).
         * @details:
         * Target Extension: sse.
         *        Data Type: int16_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1054
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct integral_all_true<simd<int16_t, sse>, Idof> {
            using Vec = simd<int16_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                
            ) {
                if constexpr(Vec::vector_element_count() < 8) {
                  return ((static_cast<typename Vec::imask_type>(1)<<Vec::vector_element_count()) - 1);
                } else {
                  return ~0;
                }
            }
        };
    } // end of namespace functors for template specialization of integral_all_true for sse using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "integral_all_true" (primitive integral_all_true).
         * @details:
         * Target Extension: sse.
         *        Data Type: int32_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1054
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct integral_all_true<simd<int32_t, sse>, Idof> {
            using Vec = simd<int32_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                
            ) {
                if constexpr(Vec::vector_element_count() < 8) {
                  return ((static_cast<typename Vec::imask_type>(1)<<Vec::vector_element_count()) - 1);
                } else {
                  return ~0;
                }
            }
        };
    } // end of namespace functors for template specialization of integral_all_true for sse using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "integral_all_true" (primitive integral_all_true).
         * @details:
         * Target Extension: sse.
         *        Data Type: int64_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1054
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct integral_all_true<simd<int64_t, sse>, Idof> {
            using Vec = simd<int64_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                
            ) {
                if constexpr(Vec::vector_element_count() < 8) {
                  return ((static_cast<typename Vec::imask_type>(1)<<Vec::vector_element_count()) - 1);
                } else {
                  return ~0;
                }
            }
        };
    } // end of namespace functors for template specialization of integral_all_true for sse using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "integral_all_true" (primitive integral_all_true).
         * @details:
         * Target Extension: sse.
         *        Data Type: float
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1054
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct integral_all_true<simd<float, sse>, Idof> {
            using Vec = simd<float, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                
            ) {
                if constexpr(Vec::vector_element_count() < 8) {
                  return ((static_cast<typename Vec::imask_type>(1)<<Vec::vector_element_count()) - 1);
                } else {
                  return ~0;
                }
            }
        };
    } // end of namespace functors for template specialization of integral_all_true for sse using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "integral_all_true" (primitive integral_all_true).
         * @details:
         * Target Extension: sse.
         *        Data Type: double
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1054
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct integral_all_true<simd<double, sse>, Idof> {
            using Vec = simd<double, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                
            ) {
                if constexpr(Vec::vector_element_count() < 8) {
                  return ((static_cast<typename Vec::imask_type>(1)<<Vec::vector_element_count()) - 1);
                } else {
                  return ~0;
                }
            }
        };
    } // end of namespace functors for template specialization of integral_all_true for sse using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "integral_all_false" (primitive integral_all_false).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint8_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1087
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct integral_all_false<simd<uint8_t, sse>, Idof> {
            using Vec = simd<uint8_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                
            ) {
                return 0;
            }
        };
    } // end of namespace functors for template specialization of integral_all_false for sse using uint8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "integral_all_false" (primitive integral_all_false).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint16_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1087
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct integral_all_false<simd<uint16_t, sse>, Idof> {
            using Vec = simd<uint16_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                
            ) {
                return 0;
            }
        };
    } // end of namespace functors for template specialization of integral_all_false for sse using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "integral_all_false" (primitive integral_all_false).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint32_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1087
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct integral_all_false<simd<uint32_t, sse>, Idof> {
            using Vec = simd<uint32_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                
            ) {
                return 0;
            }
        };
    } // end of namespace functors for template specialization of integral_all_false for sse using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "integral_all_false" (primitive integral_all_false).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint64_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1087
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct integral_all_false<simd<uint64_t, sse>, Idof> {
            using Vec = simd<uint64_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                
            ) {
                return 0;
            }
        };
    } // end of namespace functors for template specialization of integral_all_false for sse using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "integral_all_false" (primitive integral_all_false).
         * @details:
         * Target Extension: sse.
         *        Data Type: int8_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1087
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct integral_all_false<simd<int8_t, sse>, Idof> {
            using Vec = simd<int8_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                
            ) {
                return 0;
            }
        };
    } // end of namespace functors for template specialization of integral_all_false for sse using int8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "integral_all_false" (primitive integral_all_false).
         * @details:
         * Target Extension: sse.
         *        Data Type: int16_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1087
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct integral_all_false<simd<int16_t, sse>, Idof> {
            using Vec = simd<int16_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                
            ) {
                return 0;
            }
        };
    } // end of namespace functors for template specialization of integral_all_false for sse using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "integral_all_false" (primitive integral_all_false).
         * @details:
         * Target Extension: sse.
         *        Data Type: int32_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1087
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct integral_all_false<simd<int32_t, sse>, Idof> {
            using Vec = simd<int32_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                
            ) {
                return 0;
            }
        };
    } // end of namespace functors for template specialization of integral_all_false for sse using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "integral_all_false" (primitive integral_all_false).
         * @details:
         * Target Extension: sse.
         *        Data Type: int64_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1087
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct integral_all_false<simd<int64_t, sse>, Idof> {
            using Vec = simd<int64_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                
            ) {
                return 0;
            }
        };
    } // end of namespace functors for template specialization of integral_all_false for sse using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "integral_all_false" (primitive integral_all_false).
         * @details:
         * Target Extension: sse.
         *        Data Type: float
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1087
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct integral_all_false<simd<float, sse>, Idof> {
            using Vec = simd<float, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                
            ) {
                return 0;
            }
        };
    } // end of namespace functors for template specialization of integral_all_false for sse using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "integral_all_false" (primitive integral_all_false).
         * @details:
         * Target Extension: sse.
         *        Data Type: double
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1087
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct integral_all_false<simd<double, sse>, Idof> {
            using Vec = simd<double, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                
            ) {
                return 0;
            }
        };
    } // end of namespace functors for template specialization of integral_all_false for sse using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "test_imask" (primitive test_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint8_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1202
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct test_imask<simd<uint8_t, sse>, Idof> {
            using Vec = simd<uint8_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                typename Vec::imask_type mask, int position
            ) {
                return (mask & (1<< position));
            }
        };
    } // end of namespace functors for template specialization of test_imask for sse using uint8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "test_imask" (primitive test_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint16_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1202
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct test_imask<simd<uint16_t, sse>, Idof> {
            using Vec = simd<uint16_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                typename Vec::imask_type mask, int position
            ) {
                return (mask & (1<< position));
            }
        };
    } // end of namespace functors for template specialization of test_imask for sse using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "test_imask" (primitive test_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint32_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1202
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct test_imask<simd<uint32_t, sse>, Idof> {
            using Vec = simd<uint32_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                typename Vec::imask_type mask, int position
            ) {
                return (mask & (1<< position));
            }
        };
    } // end of namespace functors for template specialization of test_imask for sse using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "test_imask" (primitive test_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint64_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1202
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct test_imask<simd<uint64_t, sse>, Idof> {
            using Vec = simd<uint64_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                typename Vec::imask_type mask, int position
            ) {
                return (mask & (1<< position));
            }
        };
    } // end of namespace functors for template specialization of test_imask for sse using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "test_imask" (primitive test_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: int8_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1202
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct test_imask<simd<int8_t, sse>, Idof> {
            using Vec = simd<int8_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                typename Vec::imask_type mask, int position
            ) {
                return (mask & (1<< position));
            }
        };
    } // end of namespace functors for template specialization of test_imask for sse using int8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "test_imask" (primitive test_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: int16_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1202
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct test_imask<simd<int16_t, sse>, Idof> {
            using Vec = simd<int16_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                typename Vec::imask_type mask, int position
            ) {
                return (mask & (1<< position));
            }
        };
    } // end of namespace functors for template specialization of test_imask for sse using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "test_imask" (primitive test_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: int32_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1202
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct test_imask<simd<int32_t, sse>, Idof> {
            using Vec = simd<int32_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                typename Vec::imask_type mask, int position
            ) {
                return (mask & (1<< position));
            }
        };
    } // end of namespace functors for template specialization of test_imask for sse using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "test_imask" (primitive test_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: int64_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1202
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct test_imask<simd<int64_t, sse>, Idof> {
            using Vec = simd<int64_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                typename Vec::imask_type mask, int position
            ) {
                return (mask & (1<< position));
            }
        };
    } // end of namespace functors for template specialization of test_imask for sse using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "test_imask" (primitive test_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: float
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1202
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct test_imask<simd<float, sse>, Idof> {
            using Vec = simd<float, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                typename Vec::imask_type mask, int position
            ) {
                return (mask & (1<< position));
            }
        };
    } // end of namespace functors for template specialization of test_imask for sse using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "test_imask" (primitive test_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: double
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1202
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct test_imask<simd<double, sse>, Idof> {
            using Vec = simd<double, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                typename Vec::imask_type mask, int position
            ) {
                return (mask & (1<< position));
            }
        };
    } // end of namespace functors for template specialization of test_imask for sse using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "insert_imask" (primitive insert_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint8_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1237
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct insert_imask<simd<uint8_t, sse>, Idof> {
            using Vec = simd<uint8_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<typename Vec::imask_type, typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                typename Vec::imask_type mask_a, typename Vec::imask_type mask_b, int position
            ) {
                return mask_a | (mask_b << position);
            }
        };
    } // end of namespace functors for template specialization of insert_imask for sse using uint8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "insert_imask" (primitive insert_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint16_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1237
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct insert_imask<simd<uint16_t, sse>, Idof> {
            using Vec = simd<uint16_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<typename Vec::imask_type, typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                typename Vec::imask_type mask_a, typename Vec::imask_type mask_b, int position
            ) {
                return mask_a | (mask_b << position);
            }
        };
    } // end of namespace functors for template specialization of insert_imask for sse using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "insert_imask" (primitive insert_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint32_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1237
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct insert_imask<simd<uint32_t, sse>, Idof> {
            using Vec = simd<uint32_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<typename Vec::imask_type, typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                typename Vec::imask_type mask_a, typename Vec::imask_type mask_b, int position
            ) {
                return mask_a | (mask_b << position);
            }
        };
    } // end of namespace functors for template specialization of insert_imask for sse using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "insert_imask" (primitive insert_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint64_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1237
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct insert_imask<simd<uint64_t, sse>, Idof> {
            using Vec = simd<uint64_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<typename Vec::imask_type, typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                typename Vec::imask_type mask_a, typename Vec::imask_type mask_b, int position
            ) {
                return mask_a | (mask_b << position);
            }
        };
    } // end of namespace functors for template specialization of insert_imask for sse using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "insert_imask" (primitive insert_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: int8_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1237
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct insert_imask<simd<int8_t, sse>, Idof> {
            using Vec = simd<int8_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<typename Vec::imask_type, typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                typename Vec::imask_type mask_a, typename Vec::imask_type mask_b, int position
            ) {
                return mask_a | (mask_b << position);
            }
        };
    } // end of namespace functors for template specialization of insert_imask for sse using int8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "insert_imask" (primitive insert_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: int16_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1237
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct insert_imask<simd<int16_t, sse>, Idof> {
            using Vec = simd<int16_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<typename Vec::imask_type, typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                typename Vec::imask_type mask_a, typename Vec::imask_type mask_b, int position
            ) {
                return mask_a | (mask_b << position);
            }
        };
    } // end of namespace functors for template specialization of insert_imask for sse using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "insert_imask" (primitive insert_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: int32_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1237
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct insert_imask<simd<int32_t, sse>, Idof> {
            using Vec = simd<int32_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<typename Vec::imask_type, typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                typename Vec::imask_type mask_a, typename Vec::imask_type mask_b, int position
            ) {
                return mask_a | (mask_b << position);
            }
        };
    } // end of namespace functors for template specialization of insert_imask for sse using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "insert_imask" (primitive insert_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: int64_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1237
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct insert_imask<simd<int64_t, sse>, Idof> {
            using Vec = simd<int64_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<typename Vec::imask_type, typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                typename Vec::imask_type mask_a, typename Vec::imask_type mask_b, int position
            ) {
                return mask_a | (mask_b << position);
            }
        };
    } // end of namespace functors for template specialization of insert_imask for sse using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "insert_imask" (primitive insert_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: float
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1237
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct insert_imask<simd<float, sse>, Idof> {
            using Vec = simd<float, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<typename Vec::imask_type, typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                typename Vec::imask_type mask_a, typename Vec::imask_type mask_b, int position
            ) {
                return mask_a | (mask_b << position);
            }
        };
    } // end of namespace functors for template specialization of insert_imask for sse using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "insert_imask" (primitive insert_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: double
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1237
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct insert_imask<simd<double, sse>, Idof> {
            using Vec = simd<double, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<typename Vec::imask_type, typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                typename Vec::imask_type mask_a, typename Vec::imask_type mask_b, int position
            ) {
                return mask_a | (mask_b << position);
            }
        };
    } // end of namespace functors for template specialization of insert_imask for sse using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "extract_imask" (primitive extract_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint8_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1269
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct extract_imask<simd<uint8_t, sse>, Idof> {
            using Vec = simd<uint8_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                typename Vec::imask_type mask, int position
            ) {
                return (mask >> position) & ((1UL << Vec::vector_element_count()) - 1);
            }
        };
    } // end of namespace functors for template specialization of extract_imask for sse using uint8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "extract_imask" (primitive extract_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint16_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1269
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct extract_imask<simd<uint16_t, sse>, Idof> {
            using Vec = simd<uint16_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                typename Vec::imask_type mask, int position
            ) {
                return (mask >> position) & ((1UL << Vec::vector_element_count()) - 1);
            }
        };
    } // end of namespace functors for template specialization of extract_imask for sse using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "extract_imask" (primitive extract_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint32_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1269
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct extract_imask<simd<uint32_t, sse>, Idof> {
            using Vec = simd<uint32_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                typename Vec::imask_type mask, int position
            ) {
                return (mask >> position) & ((1UL << Vec::vector_element_count()) - 1);
            }
        };
    } // end of namespace functors for template specialization of extract_imask for sse using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "extract_imask" (primitive extract_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint64_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1269
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct extract_imask<simd<uint64_t, sse>, Idof> {
            using Vec = simd<uint64_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                typename Vec::imask_type mask, int position
            ) {
                return (mask >> position) & ((1UL << Vec::vector_element_count()) - 1);
            }
        };
    } // end of namespace functors for template specialization of extract_imask for sse using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "extract_imask" (primitive extract_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: int8_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1269
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct extract_imask<simd<int8_t, sse>, Idof> {
            using Vec = simd<int8_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                typename Vec::imask_type mask, int position
            ) {
                return (mask >> position) & ((1UL << Vec::vector_element_count()) - 1);
            }
        };
    } // end of namespace functors for template specialization of extract_imask for sse using int8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "extract_imask" (primitive extract_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: int16_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1269
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct extract_imask<simd<int16_t, sse>, Idof> {
            using Vec = simd<int16_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                typename Vec::imask_type mask, int position
            ) {
                return (mask >> position) & ((1UL << Vec::vector_element_count()) - 1);
            }
        };
    } // end of namespace functors for template specialization of extract_imask for sse using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "extract_imask" (primitive extract_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: int32_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1269
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct extract_imask<simd<int32_t, sse>, Idof> {
            using Vec = simd<int32_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                typename Vec::imask_type mask, int position
            ) {
                return (mask >> position) & ((1UL << Vec::vector_element_count()) - 1);
            }
        };
    } // end of namespace functors for template specialization of extract_imask for sse using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "extract_imask" (primitive extract_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: int64_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1269
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct extract_imask<simd<int64_t, sse>, Idof> {
            using Vec = simd<int64_t, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                typename Vec::imask_type mask, int position
            ) {
                return (mask >> position) & ((1UL << Vec::vector_element_count()) - 1);
            }
        };
    } // end of namespace functors for template specialization of extract_imask for sse using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "extract_imask" (primitive extract_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: float
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1269
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct extract_imask<simd<float, sse>, Idof> {
            using Vec = simd<float, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                typename Vec::imask_type mask, int position
            ) {
                return (mask >> position) & ((1UL << Vec::vector_element_count()) - 1);
            }
        };
    } // end of namespace functors for template specialization of extract_imask for sse using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "extract_imask" (primitive extract_mask).
         * @details:
         * Target Extension: sse.
         *        Data Type: double
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/mask.yaml::1269
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct extract_imask<simd<double, sse>, Idof> {
            using Vec = simd<double, sse>;
            
            using return_type = typename Vec::imask_type;
            using param_tuple_t = std::tuple<typename Vec::imask_type, int>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::imask_type apply(
                typename Vec::imask_type mask, int position
            ) {
                return (mask >> position) & ((1UL << Vec::vector_element_count()) - 1);
            }
        };
    } // end of namespace functors for template specialization of extract_imask for sse using double.

} // end of namespace tsl
#endif //TUD_D2RG_TSL_GITHUB_WORKSPACE_CI_GENERATION_SSE_INCLUDE_GENERATED_DEFINITIONS_MASK_MASK_SSE_HPP