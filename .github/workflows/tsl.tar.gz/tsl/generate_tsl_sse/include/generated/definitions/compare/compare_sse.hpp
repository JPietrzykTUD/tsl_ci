/*==========================================================================*
 * This file is part of the TSL - a template SIMD library.                  *
 *                                                                          *
 * Copyright 2024 TSL-Team, Database Research Group TU Dresden              *
 *                                                                          *
 * Licensed under the Apache License, Version 2.0 (the "License");          *
 * you may not use this file except in compliance with the License.         *
 * You may obtain a copy of the License at                                  *
 *                                                                          *
 *     http://www.apache.org/licenses/LICENSE-2.0                           *
 *                                                                          *
 * Unless required by applicable law or agreed to in writing, software      *
 * distributed under the License is distributed on an "AS IS" BASIS,        *
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. *
 * See the License for the specific language governing permissions and      *
 * limitations under the License.                                           *
 *==========================================================================*/
/*
 * \file /github/workspace/ci/generation/sse/include/generated/definitions/compare/compare_sse.hpp
 * \date 2024-03-05
 * \brief Compare primitives.
 * \note
 * Git-Local Url : /github/workspace
 * Git-Remote Url: unknown url
 * Git-Branch    : unknown branch
 * Git-Commit    : unknown commit (unknown commit)
 *
 */
#ifndef TUD_D2RG_TSL_GITHUB_WORKSPACE_CI_GENERATION_SSE_INCLUDE_GENERATED_DEFINITIONS_COMPARE_COMPARE_SSE_HPP
#define TUD_D2RG_TSL_GITHUB_WORKSPACE_CI_GENERATION_SSE_INCLUDE_GENERATED_DEFINITIONS_COMPARE_COMPARE_SSE_HPP

#include "../../declarations/compare.hpp"
#include <tuple>

namespace tsl {

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "equal" (primitive equal).
         * @details:
         * Target Extension: sse.
         *        Data Type: float
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/compare.yaml::123
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct equal<simd<float, sse>, Idof> {
            using Vec = simd<float, sse>;
            
            using return_type = typename Vec::mask_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type, const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename Vec::mask_type apply(
                const typename Vec::register_type vec_a, const typename Vec::register_type vec_b
            ) {
                return _mm_cmpeq_ps(vec_a, vec_b);
            }
        };
    } // end of namespace functors for template specialization of equal for sse using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "equal_masks" (primitive equal).
         * @details:
         * Target Extension: sse.
         *        Data Type: int8_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/compare.yaml::290
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct equal_masks<simd<int8_t, sse>, Idof> {
            using Vec = simd<int8_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<const typename Vec::imask_type, const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                const typename Vec::imask_type mask_a, const typename Vec::imask_type mask_b
            ) {
                return mask_a == mask_b;
            }
        };
    } // end of namespace functors for template specialization of equal_masks for sse using int8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "equal_masks" (primitive equal).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint8_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/compare.yaml::290
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct equal_masks<simd<uint8_t, sse>, Idof> {
            using Vec = simd<uint8_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<const typename Vec::imask_type, const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                const typename Vec::imask_type mask_a, const typename Vec::imask_type mask_b
            ) {
                return mask_a == mask_b;
            }
        };
    } // end of namespace functors for template specialization of equal_masks for sse using uint8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "equal_masks" (primitive equal).
         * @details:
         * Target Extension: sse.
         *        Data Type: int16_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/compare.yaml::290
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct equal_masks<simd<int16_t, sse>, Idof> {
            using Vec = simd<int16_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<const typename Vec::imask_type, const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                const typename Vec::imask_type mask_a, const typename Vec::imask_type mask_b
            ) {
                return mask_a == mask_b;
            }
        };
    } // end of namespace functors for template specialization of equal_masks for sse using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "equal_masks" (primitive equal).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint16_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/compare.yaml::290
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct equal_masks<simd<uint16_t, sse>, Idof> {
            using Vec = simd<uint16_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<const typename Vec::imask_type, const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                const typename Vec::imask_type mask_a, const typename Vec::imask_type mask_b
            ) {
                return mask_a == mask_b;
            }
        };
    } // end of namespace functors for template specialization of equal_masks for sse using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "equal_masks" (primitive equal).
         * @details:
         * Target Extension: sse.
         *        Data Type: int32_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/compare.yaml::290
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct equal_masks<simd<int32_t, sse>, Idof> {
            using Vec = simd<int32_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<const typename Vec::imask_type, const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                const typename Vec::imask_type mask_a, const typename Vec::imask_type mask_b
            ) {
                return mask_a == mask_b;
            }
        };
    } // end of namespace functors for template specialization of equal_masks for sse using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "equal_masks" (primitive equal).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint32_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/compare.yaml::290
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct equal_masks<simd<uint32_t, sse>, Idof> {
            using Vec = simd<uint32_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<const typename Vec::imask_type, const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                const typename Vec::imask_type mask_a, const typename Vec::imask_type mask_b
            ) {
                return mask_a == mask_b;
            }
        };
    } // end of namespace functors for template specialization of equal_masks for sse using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "equal_masks" (primitive equal).
         * @details:
         * Target Extension: sse.
         *        Data Type: int64_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/compare.yaml::290
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct equal_masks<simd<int64_t, sse>, Idof> {
            using Vec = simd<int64_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<const typename Vec::imask_type, const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                const typename Vec::imask_type mask_a, const typename Vec::imask_type mask_b
            ) {
                return mask_a == mask_b;
            }
        };
    } // end of namespace functors for template specialization of equal_masks for sse using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "equal_masks" (primitive equal).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint64_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/compare.yaml::290
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct equal_masks<simd<uint64_t, sse>, Idof> {
            using Vec = simd<uint64_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<const typename Vec::imask_type, const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                const typename Vec::imask_type mask_a, const typename Vec::imask_type mask_b
            ) {
                return mask_a == mask_b;
            }
        };
    } // end of namespace functors for template specialization of equal_masks for sse using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "equal_masks" (primitive equal).
         * @details:
         * Target Extension: sse.
         *        Data Type: float
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/compare.yaml::290
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct equal_masks<simd<float, sse>, Idof> {
            using Vec = simd<float, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<const typename Vec::imask_type, const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                const typename Vec::imask_type mask_a, const typename Vec::imask_type mask_b
            ) {
                return mask_a == mask_b;
            }
        };
    } // end of namespace functors for template specialization of equal_masks for sse using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "equal_masks" (primitive equal).
         * @details:
         * Target Extension: sse.
         *        Data Type: double
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/compare.yaml::290
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct equal_masks<simd<double, sse>, Idof> {
            using Vec = simd<double, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<const typename Vec::imask_type, const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                const typename Vec::imask_type mask_a, const typename Vec::imask_type mask_b
            ) {
                return mask_a == mask_b;
            }
        };
    } // end of namespace functors for template specialization of equal_masks for sse using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "nequal_masks" (primitive nequal).
         * @details:
         * Target Extension: sse.
         *        Data Type: int8_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/compare.yaml::551
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct nequal_masks<simd<int8_t, sse>, Idof> {
            using Vec = simd<int8_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<const typename Vec::imask_type, const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                const typename Vec::imask_type mask_a, const typename Vec::imask_type mask_b
            ) {
                return mask_a != mask_b;
            }
        };
    } // end of namespace functors for template specialization of nequal_masks for sse using int8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "nequal_masks" (primitive nequal).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint8_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/compare.yaml::551
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct nequal_masks<simd<uint8_t, sse>, Idof> {
            using Vec = simd<uint8_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<const typename Vec::imask_type, const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                const typename Vec::imask_type mask_a, const typename Vec::imask_type mask_b
            ) {
                return mask_a != mask_b;
            }
        };
    } // end of namespace functors for template specialization of nequal_masks for sse using uint8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "nequal_masks" (primitive nequal).
         * @details:
         * Target Extension: sse.
         *        Data Type: int16_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/compare.yaml::551
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct nequal_masks<simd<int16_t, sse>, Idof> {
            using Vec = simd<int16_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<const typename Vec::imask_type, const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                const typename Vec::imask_type mask_a, const typename Vec::imask_type mask_b
            ) {
                return mask_a != mask_b;
            }
        };
    } // end of namespace functors for template specialization of nequal_masks for sse using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "nequal_masks" (primitive nequal).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint16_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/compare.yaml::551
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct nequal_masks<simd<uint16_t, sse>, Idof> {
            using Vec = simd<uint16_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<const typename Vec::imask_type, const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                const typename Vec::imask_type mask_a, const typename Vec::imask_type mask_b
            ) {
                return mask_a != mask_b;
            }
        };
    } // end of namespace functors for template specialization of nequal_masks for sse using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "nequal_masks" (primitive nequal).
         * @details:
         * Target Extension: sse.
         *        Data Type: int32_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/compare.yaml::551
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct nequal_masks<simd<int32_t, sse>, Idof> {
            using Vec = simd<int32_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<const typename Vec::imask_type, const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                const typename Vec::imask_type mask_a, const typename Vec::imask_type mask_b
            ) {
                return mask_a != mask_b;
            }
        };
    } // end of namespace functors for template specialization of nequal_masks for sse using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "nequal_masks" (primitive nequal).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint32_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/compare.yaml::551
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct nequal_masks<simd<uint32_t, sse>, Idof> {
            using Vec = simd<uint32_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<const typename Vec::imask_type, const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                const typename Vec::imask_type mask_a, const typename Vec::imask_type mask_b
            ) {
                return mask_a != mask_b;
            }
        };
    } // end of namespace functors for template specialization of nequal_masks for sse using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "nequal_masks" (primitive nequal).
         * @details:
         * Target Extension: sse.
         *        Data Type: int64_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/compare.yaml::551
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct nequal_masks<simd<int64_t, sse>, Idof> {
            using Vec = simd<int64_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<const typename Vec::imask_type, const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                const typename Vec::imask_type mask_a, const typename Vec::imask_type mask_b
            ) {
                return mask_a != mask_b;
            }
        };
    } // end of namespace functors for template specialization of nequal_masks for sse using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "nequal_masks" (primitive nequal).
         * @details:
         * Target Extension: sse.
         *        Data Type: uint64_t
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/compare.yaml::551
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct nequal_masks<simd<uint64_t, sse>, Idof> {
            using Vec = simd<uint64_t, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<const typename Vec::imask_type, const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                const typename Vec::imask_type mask_a, const typename Vec::imask_type mask_b
            ) {
                return mask_a != mask_b;
            }
        };
    } // end of namespace functors for template specialization of nequal_masks for sse using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "nequal_masks" (primitive nequal).
         * @details:
         * Target Extension: sse.
         *        Data Type: float
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/compare.yaml::551
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct nequal_masks<simd<float, sse>, Idof> {
            using Vec = simd<float, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<const typename Vec::imask_type, const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                const typename Vec::imask_type mask_a, const typename Vec::imask_type mask_b
            ) {
                return mask_a != mask_b;
            }
        };
    } // end of namespace functors for template specialization of nequal_masks for sse using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "nequal_masks" (primitive nequal).
         * @details:
         * Target Extension: sse.
         *        Data Type: double
         *  Extension Flags: ['sse']
         *      Yaml Source: primitive_data/primitives/compare.yaml::551
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct nequal_masks<simd<double, sse>, Idof> {
            using Vec = simd<double, sse>;
            
            using return_type = bool;
            using param_tuple_t = std::tuple<const typename Vec::imask_type, const typename Vec::imask_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static bool apply(
                const typename Vec::imask_type mask_a, const typename Vec::imask_type mask_b
            ) {
                return mask_a != mask_b;
            }
        };
    } // end of namespace functors for template specialization of nequal_masks for sse using double.

} // end of namespace tsl
#endif //TUD_D2RG_TSL_GITHUB_WORKSPACE_CI_GENERATION_SSE_INCLUDE_GENERATED_DEFINITIONS_COMPARE_COMPARE_SSE_HPP