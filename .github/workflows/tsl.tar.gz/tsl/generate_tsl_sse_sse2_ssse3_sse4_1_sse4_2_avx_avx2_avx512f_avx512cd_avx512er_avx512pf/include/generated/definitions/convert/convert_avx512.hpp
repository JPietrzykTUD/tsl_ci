/*==========================================================================*
 * This file is part of the TSL - a template SIMD library.                  *
 *                                                                          *
 * Copyright 2024 TSL-Team, Database Research Group TU Dresden              *
 *                                                                          *
 * Licensed under the Apache License, Version 2.0 (the "License");          *
 * you may not use this file except in compliance with the License.         *
 * You may obtain a copy of the License at                                  *
 *                                                                          *
 *     http://www.apache.org/licenses/LICENSE-2.0                           *
 *                                                                          *
 * Unless required by applicable law or agreed to in writing, software      *
 * distributed under the License is distributed on an "AS IS" BASIS,        *
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. *
 * See the License for the specific language governing permissions and      *
 * limitations under the License.                                           *
 *==========================================================================*/
/*
 * \file /github/workspace/ci/generation/sse_sse2_ssse3_sse4_1_sse4_2_avx_avx2_avx512f_avx512cd_avx512er_avx512pf/include/generated/definitions/convert/convert_avx512.hpp
 * \date 2024-03-05
 * \brief Conversion primitives.
 * \note
 * Git-Local Url : /github/workspace
 * Git-Remote Url: unknown url
 * Git-Branch    : unknown branch
 * Git-Commit    : unknown commit (unknown commit)
 *
 */
#ifndef TUD_D2RG_TSL_GITHUB_WORKSPACE_CI_GENERATION_SSE_SSE2_SSSE3_SSE4_1_SSE4_2_AVX_AVX2_AVX512F_AVX512CD_AVX512ER_AVX512PF_INCLUDE_GENERATED_DEFINITIONS_CONVERT_CONVERT_AVX512_HPP
#define TUD_D2RG_TSL_GITHUB_WORKSPACE_CI_GENERATION_SSE_SSE2_SSSE3_SSE4_1_SSE4_2_AVX_AVX2_AVX512F_AVX512CD_AVX512ER_AVX512PF_INCLUDE_GENERATED_DEFINITIONS_CONVERT_CONVERT_AVX512_HPP

#include "../../declarations/convert.hpp"
#include <tuple>

namespace tsl {

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::17
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<int8_t, avx512>, simd<int8_t, avx512>, Idof> {
            using Vec = simd<int8_t, avx512>;
            using ToType = simd<int8_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return data;
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using int8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::17
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<uint8_t, avx512>, simd<uint8_t, avx512>, Idof> {
            using Vec = simd<uint8_t, avx512>;
            using ToType = simd<uint8_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return data;
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using uint8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::17
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<int16_t, avx512>, simd<int16_t, avx512>, Idof> {
            using Vec = simd<int16_t, avx512>;
            using ToType = simd<int16_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return data;
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::17
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<uint16_t, avx512>, simd<uint16_t, avx512>, Idof> {
            using Vec = simd<uint16_t, avx512>;
            using ToType = simd<uint16_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return data;
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::17
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<int32_t, avx512>, simd<int32_t, avx512>, Idof> {
            using Vec = simd<int32_t, avx512>;
            using ToType = simd<int32_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return data;
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::17
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<uint32_t, avx512>, simd<uint32_t, avx512>, Idof> {
            using Vec = simd<uint32_t, avx512>;
            using ToType = simd<uint32_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return data;
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::17
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<int64_t, avx512>, simd<int64_t, avx512>, Idof> {
            using Vec = simd<int64_t, avx512>;
            using ToType = simd<int64_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return data;
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::17
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<uint64_t, avx512>, simd<uint64_t, avx512>, Idof> {
            using Vec = simd<uint64_t, avx512>;
            using ToType = simd<uint64_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return data;
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::17
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<float, avx512>, simd<float, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            using ToType = simd<float, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return data;
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: double
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::17
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<double, avx512>, simd<double, avx512>, Idof> {
            using Vec = simd<double, avx512>;
            using ToType = simd<double, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return data;
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::22
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<int8_t, avx512>, simd<float, avx512>, Idof> {
            using Vec = simd<int8_t, avx512>;
            using ToType = simd<float, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castsi512_ps(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using int8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::22
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<uint8_t, avx512>, simd<float, avx512>, Idof> {
            using Vec = simd<uint8_t, avx512>;
            using ToType = simd<float, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castsi512_ps(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using uint8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::22
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<int16_t, avx512>, simd<float, avx512>, Idof> {
            using Vec = simd<int16_t, avx512>;
            using ToType = simd<float, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castsi512_ps(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::22
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<uint16_t, avx512>, simd<float, avx512>, Idof> {
            using Vec = simd<uint16_t, avx512>;
            using ToType = simd<float, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castsi512_ps(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::22
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<int32_t, avx512>, simd<float, avx512>, Idof> {
            using Vec = simd<int32_t, avx512>;
            using ToType = simd<float, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castsi512_ps(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::22
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<uint32_t, avx512>, simd<float, avx512>, Idof> {
            using Vec = simd<uint32_t, avx512>;
            using ToType = simd<float, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castsi512_ps(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::22
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<int64_t, avx512>, simd<float, avx512>, Idof> {
            using Vec = simd<int64_t, avx512>;
            using ToType = simd<float, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castsi512_ps(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::22
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<uint64_t, avx512>, simd<float, avx512>, Idof> {
            using Vec = simd<uint64_t, avx512>;
            using ToType = simd<float, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castsi512_ps(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::27
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<float, avx512>, simd<int8_t, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            using ToType = simd<int8_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castps_si512(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::27
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<float, avx512>, simd<uint8_t, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            using ToType = simd<uint8_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castps_si512(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::27
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<float, avx512>, simd<int16_t, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            using ToType = simd<int16_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castps_si512(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::27
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<float, avx512>, simd<uint16_t, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            using ToType = simd<uint16_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castps_si512(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::27
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<float, avx512>, simd<int32_t, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            using ToType = simd<int32_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castps_si512(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::27
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<float, avx512>, simd<uint32_t, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            using ToType = simd<uint32_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castps_si512(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::27
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<float, avx512>, simd<int64_t, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            using ToType = simd<int64_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castps_si512(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::27
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<float, avx512>, simd<uint64_t, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            using ToType = simd<uint64_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castps_si512(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::32
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<int8_t, avx512>, simd<double, avx512>, Idof> {
            using Vec = simd<int8_t, avx512>;
            using ToType = simd<double, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castsi512_pd(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using int8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint8_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::32
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<uint8_t, avx512>, simd<double, avx512>, Idof> {
            using Vec = simd<uint8_t, avx512>;
            using ToType = simd<double, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castsi512_pd(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using uint8_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::32
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<int16_t, avx512>, simd<double, avx512>, Idof> {
            using Vec = simd<int16_t, avx512>;
            using ToType = simd<double, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castsi512_pd(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint16_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::32
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<uint16_t, avx512>, simd<double, avx512>, Idof> {
            using Vec = simd<uint16_t, avx512>;
            using ToType = simd<double, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castsi512_pd(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::32
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<int32_t, avx512>, simd<double, avx512>, Idof> {
            using Vec = simd<int32_t, avx512>;
            using ToType = simd<double, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castsi512_pd(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::32
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<uint32_t, avx512>, simd<double, avx512>, Idof> {
            using Vec = simd<uint32_t, avx512>;
            using ToType = simd<double, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castsi512_pd(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::32
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<int64_t, avx512>, simd<double, avx512>, Idof> {
            using Vec = simd<int64_t, avx512>;
            using ToType = simd<double, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castsi512_pd(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::32
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<uint64_t, avx512>, simd<double, avx512>, Idof> {
            using Vec = simd<uint64_t, avx512>;
            using ToType = simd<double, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castsi512_pd(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: double
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::37
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<double, avx512>, simd<int8_t, avx512>, Idof> {
            using Vec = simd<double, avx512>;
            using ToType = simd<int8_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castpd_si512(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: double
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::37
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<double, avx512>, simd<uint8_t, avx512>, Idof> {
            using Vec = simd<double, avx512>;
            using ToType = simd<uint8_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castpd_si512(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: double
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::37
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<double, avx512>, simd<int16_t, avx512>, Idof> {
            using Vec = simd<double, avx512>;
            using ToType = simd<int16_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castpd_si512(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: double
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::37
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<double, avx512>, simd<uint16_t, avx512>, Idof> {
            using Vec = simd<double, avx512>;
            using ToType = simd<uint16_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castpd_si512(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: double
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::37
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<double, avx512>, simd<int32_t, avx512>, Idof> {
            using Vec = simd<double, avx512>;
            using ToType = simd<int32_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castpd_si512(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: double
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::37
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<double, avx512>, simd<uint32_t, avx512>, Idof> {
            using Vec = simd<double, avx512>;
            using ToType = simd<uint32_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castpd_si512(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: double
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::37
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<double, avx512>, simd<int64_t, avx512>, Idof> {
            using Vec = simd<double, avx512>;
            using ToType = simd<int64_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castpd_si512(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "reinterpret" (primitive reinterpret).
         * @details:
         * Target Extension: avx512.
         *        Data Type: double
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::37
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct reinterpret<simd<double, avx512>, simd<uint64_t, avx512>, Idof> {
            using Vec = simd<double, avx512>;
            using ToType = simd<uint64_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_castpd_si512(data);
            }
        };
    } // end of namespace functors for template specialization of reinterpret for avx512 using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "cast" (primitive cast).
         * @details:
         * Target Extension: avx512.
         *        Data Type: double
         *  Extension Flags: ['avx2', 'avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::246
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct cast<simd<double, avx512>, simd<float, avx2>, Idof> {
            using Vec = simd<double, avx512>;
            using ToType = simd<float, avx2>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_cvtpd_ps(data);
            }
        };
    } // end of namespace functors for template specialization of cast for avx512 using double.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "cast" (primitive cast).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int16_t
         *  Extension Flags: ['avx2', 'avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::246
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct cast<simd<int16_t, avx512>, simd<int8_t, avx2>, Idof> {
            using Vec = simd<int16_t, avx512>;
            using ToType = simd<int8_t, avx2>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_cvtepi16_epi8(data);
            }
        };
    } // end of namespace functors for template specialization of cast for avx512 using int16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "cast" (primitive cast).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int32_t
         *  Extension Flags: ['avx2', 'avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::246
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct cast<simd<int32_t, avx512>, simd<int16_t, avx2>, Idof> {
            using Vec = simd<int32_t, avx512>;
            using ToType = simd<int16_t, avx2>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_cvtepi32_epi16(data);
            }
        };
    } // end of namespace functors for template specialization of cast for avx512 using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "cast" (primitive cast).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int64_t
         *  Extension Flags: ['avx2', 'avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::246
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct cast<simd<int64_t, avx512>, simd<int32_t, avx2>, Idof> {
            using Vec = simd<int64_t, avx512>;
            using ToType = simd<int32_t, avx2>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_cvtepi64_epi32(data);
            }
        };
    } // end of namespace functors for template specialization of cast for avx512 using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "cast" (primitive cast).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint16_t
         *  Extension Flags: ['avx2', 'avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::246
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct cast<simd<uint16_t, avx512>, simd<uint8_t, avx2>, Idof> {
            using Vec = simd<uint16_t, avx512>;
            using ToType = simd<uint8_t, avx2>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_cvtepi16_epi8(data);
            }
        };
    } // end of namespace functors for template specialization of cast for avx512 using uint16_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "cast" (primitive cast).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint32_t
         *  Extension Flags: ['avx2', 'avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::246
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct cast<simd<uint32_t, avx512>, simd<uint16_t, avx2>, Idof> {
            using Vec = simd<uint32_t, avx512>;
            using ToType = simd<uint16_t, avx2>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_cvtepi32_epi16(data);
            }
        };
    } // end of namespace functors for template specialization of cast for avx512 using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "cast" (primitive cast).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint64_t
         *  Extension Flags: ['avx2', 'avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::246
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct cast<simd<uint64_t, avx512>, simd<uint32_t, avx2>, Idof> {
            using Vec = simd<uint64_t, avx512>;
            using ToType = simd<uint32_t, avx2>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_cvtepi64_epi32(data);
            }
        };
    } // end of namespace functors for template specialization of cast for avx512 using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "cast" (primitive cast).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::266
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct cast<simd<int32_t, avx512>, simd<int8_t, sse>, Idof> {
            using Vec = simd<int32_t, avx512>;
            using ToType = simd<int8_t, sse>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_cvtepi32_epi8(data);
            }
        };
    } // end of namespace functors for template specialization of cast for avx512 using int32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "cast" (primitive cast).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::266
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct cast<simd<uint32_t, avx512>, simd<uint8_t, sse>, Idof> {
            using Vec = simd<uint32_t, avx512>;
            using ToType = simd<uint8_t, sse>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_cvtepi32_epi8(data);
            }
        };
    } // end of namespace functors for template specialization of cast for avx512 using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "cast" (primitive cast).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::266
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct cast<simd<int64_t, avx512>, simd<int16_t, sse>, Idof> {
            using Vec = simd<int64_t, avx512>;
            using ToType = simd<int16_t, sse>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_cvtepi64_epi16(data);
            }
        };
    } // end of namespace functors for template specialization of cast for avx512 using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "cast" (primitive cast).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::266
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct cast<simd<int64_t, avx512>, simd<int8_t, sse>, Idof> {
            using Vec = simd<int64_t, avx512>;
            using ToType = simd<int8_t, sse>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_cvtepi64_epi8(data);
            }
        };
    } // end of namespace functors for template specialization of cast for avx512 using int64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "cast" (primitive cast).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::266
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct cast<simd<uint64_t, avx512>, simd<uint16_t, sse>, Idof> {
            using Vec = simd<uint64_t, avx512>;
            using ToType = simd<uint16_t, sse>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_cvtepi64_epi16(data);
            }
        };
    } // end of namespace functors for template specialization of cast for avx512 using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "cast" (primitive cast).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint64_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::266
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct cast<simd<uint64_t, avx512>, simd<uint8_t, sse>, Idof> {
            using Vec = simd<uint64_t, avx512>;
            using ToType = simd<uint8_t, sse>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_cvtepi64_epi8(data);
            }
        };
    } // end of namespace functors for template specialization of cast for avx512 using uint64_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "cast" (primitive cast).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::303
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct cast<simd<float, avx512>, simd<int32_t, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            using ToType = simd<int32_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_cvtps_epi32(_mm512_roundscale_ps(data, _MM_FROUND_TO_ZERO));
            }
        };
    } // end of namespace functors for template specialization of cast for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "cast" (primitive cast).
         * @details:
         * Target Extension: avx512.
         *        Data Type: float
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::308
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct cast<simd<float, avx512>, simd<uint32_t, avx512>, Idof> {
            using Vec = simd<float, avx512>;
            using ToType = simd<uint32_t, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_cvtps_epu32(_mm512_roundscale_ps(data, _MM_FROUND_TO_ZERO));
            }
        };
    } // end of namespace functors for template specialization of cast for avx512 using float.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "cast" (primitive cast).
         * @details:
         * Target Extension: avx512.
         *        Data Type: uint32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::364
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct cast<simd<uint32_t, avx512>, simd<float, avx512>, Idof> {
            using Vec = simd<uint32_t, avx512>;
            using ToType = simd<float, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_cvtepu32_ps(data);
            }
        };
    } // end of namespace functors for template specialization of cast for avx512 using uint32_t.

    namespace functors {
        /**
         * @brief: Template specialization of implementation for "cast" (primitive cast).
         * @details:
         * Target Extension: avx512.
         *        Data Type: int32_t
         *  Extension Flags: ['avx512f']
         *      Yaml Source: primitive_data/primitives/convert.yaml::364
         */
        template<ImplementationDegreeOfFreedom Idof>
        struct cast<simd<int32_t, avx512>, simd<float, avx512>, Idof> {
            using Vec = simd<int32_t, avx512>;
            using ToType = simd<float, avx512>;
            using return_type = typename ToType::register_type;
            using param_tuple_t = std::tuple<const typename Vec::register_type>;
            static constexpr bool parameters_queryable() {
                return true;
            }
            static constexpr bool has_return_value() {
                return true;
            }
            static constexpr bool native_supported() {
                return true;
            }
            [[nodiscard]] 
            TSL_FORCE_INLINE 
            static typename ToType::register_type apply(
                const typename Vec::register_type data
            ) {
                return _mm512_cvtepi32_ps(data);
            }
        };
    } // end of namespace functors for template specialization of cast for avx512 using int32_t.

} // end of namespace tsl
#endif //TUD_D2RG_TSL_GITHUB_WORKSPACE_CI_GENERATION_SSE_SSE2_SSSE3_SSE4_1_SSE4_2_AVX_AVX2_AVX512F_AVX512CD_AVX512ER_AVX512PF_INCLUDE_GENERATED_DEFINITIONS_CONVERT_CONVERT_AVX512_HPP